! function (e) {
    "use strict";
    var t = {
        init: function (a) {
            var r = this;
            return r.data("jqv") && null != r.data("jqv") || (a = t._saveOptions(r, a), e(document).on("click", ".formError", function () {
                e(this).fadeOut(150, function () {
                    e(this).parent(".formErrorOuter").remove(), e(this).remove()
                })
            })), this
        },
        attach: function (a) {
            var r, i = this;
            return r = a ? t._saveOptions(i, a) : i.data("jqv"), r.validateAttribute = i.find("[data-validation-engine*=validate]").length ? "data-validation-engine" : "class", r.binded && (i.on(r.validationEventTrigger, "[" + r.validateAttribute + "*=validate]:not([type=checkbox]):not([type=radio]):not(.datepicker)", t._onFieldEvent), i.on("click", "[" + r.validateAttribute + "*=validate][type=checkbox],[" + r.validateAttribute + "*=validate][type=radio]", t._onFieldEvent), i.on(r.validationEventTrigger, "[" + r.validateAttribute + "*=validate][class*=datepicker]", {
                delay: 300
            }, t._onFieldEvent)), r.autoPositionUpdate && e(window).bind("resize", {
                noAnimation: !0,
                formElem: i
            }, t.updatePromptsPosition), i.on("click", "a[data-validation-engine-skip], a[class*='validate-skip'], button[data-validation-engine-skip], button[class*='validate-skip'], input[data-validation-engine-skip], input[class*='validate-skip']", t._submitButtonClick), i.removeData("jqv_submitButton"), i.on("submit", t._onSubmitEvent), this
        },
        detach: function () {
            var a = this,
                r = a.data("jqv");
            return a.find("[" + r.validateAttribute + "*=validate]").not("[type=checkbox]").off(r.validationEventTrigger, t._onFieldEvent), a.find("[" + r.validateAttribute + "*=validate][type=checkbox],[class*=validate][type=radio]").off("click", t._onFieldEvent), a.off("submit", t._onSubmitEvent), a.removeData("jqv"), a.off("click", "a[data-validation-engine-skip], a[class*='validate-skip'], button[data-validation-engine-skip], button[class*='validate-skip'], input[data-validation-engine-skip], input[class*='validate-skip']", t._submitButtonClick), a.removeData("jqv_submitButton"), r.autoPositionUpdate && e(window).off("resize", t.updatePromptsPosition), this
        },
        validate: function () {
            var a = e(this),
                r = null;
            if (a.is("form") || a.hasClass("validationEngineContainer")) {
                if (a.hasClass("validating")) return !1;
                a.addClass("validating");
                var i = a.data("jqv"),
                    r = t._validateFields(this);
                setTimeout(function () {
                    a.removeClass("validating")
                }, 100), r && i.onSuccess ? i.onSuccess() : !r && i.onFailure && i.onFailure()
            } else if (a.is("form") || a.hasClass("validationEngineContainer")) a.removeClass("validating");
            else {
                var o = a.closest("form, .validationEngineContainer"),
                    i = o.data("jqv") ? o.data("jqv") : e.validationEngine.defaults,
                    r = t._validateField(a, i);
                r && i.onFieldSuccess ? i.onFieldSuccess() : i.onFieldFailure && i.InvalidFields.length > 0 && i.onFieldFailure()
            }
            return i.onValidationComplete ? !!i.onValidationComplete(o, r) : r
        },
        updatePromptsPosition: function (a) {
            if (a && this == window) var r = a.data.formElem,
                i = a.data.noAnimation;
            else var r = e(this.closest("form, .validationEngineContainer"));
            var o = r.data("jqv");
            return r.find("[" + o.validateAttribute + "*=validate]").not(":disabled").each(function () {
                var a = e(this);
                o.prettySelect && a.is(":hidden") && (a = r.find("#" + o.usePrefix + a.attr("id") + o.useSuffix));
                var s = t._getPrompt(a),
                    n = e(s).find(".formErrorContent").html();
                s && t._updatePrompt(a, e(s), n, void 0, !1, o, i)
            }), this
        },
        showPrompt: function (e, a, r, i) {
            var o = this.closest("form, .validationEngineContainer"),
                s = o.data("jqv");
            return s || (s = t._saveOptions(this, s)), r && (s.promptPosition = r), s.showArrow = 1 == i, t._showPrompt(this, e, a, !1, s), this
        },
        hide: function () {
            var a, r = e(this).closest("form, .validationEngineContainer"),
                i = r.data("jqv"),
                o = i && i.fadeDuration ? i.fadeDuration : .3;
            return a = e(this).is("form") || e(this).hasClass("validationEngineContainer") ? "parentForm" + t._getClassName(e(this).attr("id")) : t._getClassName(e(this).attr("id")) + "formError", e("." + a).fadeTo(o, .3, function () {
                e(this).parent(".formErrorOuter").remove(), e(this).remove()
            }), this
        },
        hideAll: function () {
            var t = this,
                a = t.data("jqv"),
                r = a ? a.fadeDuration : 300;
            return e(".formError").fadeTo(r, 300, function () {
                e(this).parent(".formErrorOuter").remove(), e(this).remove()
            }), this
        },
        _onFieldEvent: function (a) {
            var r = e(this),
                i = r.closest("form, .validationEngineContainer"),
                o = i.data("jqv");
            o.eventTrigger = "field", window.setTimeout(function () {
                t._validateField(r, o), 0 == o.InvalidFields.length && o.onFieldSuccess ? o.onFieldSuccess() : o.InvalidFields.length > 0 && o.onFieldFailure && o.onFieldFailure()
            }, a.data ? a.data.delay : 0)
        },
        _onSubmitEvent: function () {
            var a = e(this),
                r = a.data("jqv");
            if (a.data("jqv_submitButton")) {
                var i = e("#" + a.data("jqv_submitButton"));
                if (i && i.length > 0 && (i.hasClass("validate-skip") || "true" == i.attr("data-validation-engine-skip"))) return !0
            }
            r.eventTrigger = "submit";
            var o = t._validateFields(a);
            return o && r.ajaxFormValidation ? (t._validateFormWithAjax(a, r), !1) : r.onValidationComplete ? !!r.onValidationComplete(a, o) : o
        },
        _checkAjaxStatus: function (t) {
            var a = !0;
            return e.each(t.ajaxValidCache, function (e, t) {
                return t ? void 0 : (a = !1, !1)
            }), a
        },
        _checkAjaxFieldStatus: function (e, t) {
            return 1 == t.ajaxValidCache[e]
        },
        _validateFields: function (a) {
            var r = a.data("jqv"),
                i = !1;
            a.trigger("jqv.form.validating");
            var o = null;
            if (a.find("[" + r.validateAttribute + "*=validate]").not(":disabled").each(function () {
                    var s = e(this),
                        n = [];
                    if (e.inArray(s.attr("name"), n) < 0) {
                        if (i |= t._validateField(s, r), i && null == o && (s.is(":hidden") && r.prettySelect ? o = s = a.find("#" + r.usePrefix + t._jqSelector(s.attr("id")) + r.useSuffix) : (s.data("jqv-prompt-at") instanceof jQuery ? s = s.data("jqv-prompt-at") : s.data("jqv-prompt-at") && (s = e(s.data("jqv-prompt-at"))), o = s)), r.doNotShowAllErrosOnSubmit) return !1;
                        if (n.push(s.attr("name")), 1 == r.showOneMessage && i) return !1
            }
            }), a.trigger("jqv.form.result", [i]), i) {
                if (r.scroll) {
                    var s = o.offset().top,
                        n = o.offset().left,
                        l = r.promptPosition;
                    if ("string" == typeof l && -1 != l.indexOf(":") && (l = l.substring(0, l.indexOf(":"))), "bottomRight" != l && "bottomLeft" != l) {
                        var d = t._getPrompt(o);
                        d && (s = d.offset().top)
                    }
                    if (r.scrollOffset && (s -= r.scrollOffset), r.isOverflown) {
                        var u = e(r.overflownDIV);
                        if (!u.length) return !1;
                        var c = u.scrollTop(),
                            f = -parseInt(u.offset().top);
                        s += c + f - 5;
                        var v = e(r.overflownDIV + ":not(:animated)");
                        v.animate({
                            scrollTop: s
                        }, 1100, function () {
                            r.focusFirstField && o.focus()
                        })
                    } else e("html, body").animate({
                        scrollTop: s
                    }, 1100, function () {
                        r.focusFirstField && o.focus()
                    }), e("html, body").animate({
                        scrollLeft: n
                    }, 1100)
                } else r.focusFirstField && o.focus();
                return !1
            }
            return !0
        },
        _validateFormWithAjax: function (a, r) {
            var i = a.serialize(),
                o = r.ajaxFormValidationMethod ? r.ajaxFormValidationMethod : "GET",
                s = r.ajaxFormValidationURL ? r.ajaxFormValidationURL : a.attr("action"),
                n = r.dataType ? r.dataType : "json";
            e.ajax({
                type: o,
                url: s,
                cache: !1,
                dataType: n,
                data: i,
                form: a,
                methods: t,
                options: r,
                beforeSend: function () {
                    return r.onBeforeAjaxFormValidation(a, r)
                },
                error: function (e, a) {
                    t._ajaxError(e, a)
                },
                success: function (i) {
                    if ("json" == n && i !== !0) {
                        for (var o = !1, s = 0; s < i.length; s++) {
                            var l = i[s],
                                d = l[0],
                                u = e(e("#" + d)[0]);
                            if (1 == u.length) {
                                var c = l[2];
                                if (1 == l[1])
                                    if ("" != c && c) {
                                        if (r.allrules[c]) {
                                            var f = r.allrules[c].alertTextOk;
                                            f && (c = f)
                                        }
                                        r.showPrompts && t._showPrompt(u, c, "pass", !1, r, !0)
                                    } else t._closePrompt(u);
                                else {
                                    if (o |= !0, r.allrules[c]) {
                                        var f = r.allrules[c].alertText;
                                        f && (c = f)
                                    }
                                    r.showPrompts && t._showPrompt(u, c, "", !1, r, !0)
                                }
                            }
                        }
                        r.onAjaxFormComplete(!o, a, i, r)
                    } else r.onAjaxFormComplete(!0, a, i, r)
                }
            })
        },
        _validateField: function (a, r, i) {
            if (a.attr("id") || (a.attr("id", "form-validation-field-" + e.validationEngine.fieldIdCounter), ++e.validationEngine.fieldIdCounter), !r.validateNonVisibleFields && (a.is(":hidden") && !r.prettySelect || a.parent().is(":hidden"))) return !1;
            var o = a.attr(r.validateAttribute),
                s = /validate\[(.*)\]/.exec(o);
            if (!s) return !1;
            var n = s[1],
                l = n.split(/\[|,|\]/),
                d = !1,
                u = a.attr("name"),
                c = "",
                f = "",
                v = !1,
                p = !1;
            r.isError = !1, r.showArrow = !0, r.maxErrorsPerField > 0 && (p = !0);
            for (var m = e(a.closest("form, .validationEngineContainer")), g = 0; g < l.length; g++) l[g] = l[g].replace(" ", ""), "" === l[g] && delete l[g];
            for (var g = 0, h = 0; g < l.length; g++) {
                if (p && h >= r.maxErrorsPerField) {
                    if (!v) {
                        var _ = e.inArray("required", l);
                        v = -1 != _ && _ >= g
                    }
                    break
                }
                var x = void 0;
                switch (l[g]) {
                    case "required":
                        v = !0, x = t._getErrorMessage(m, a, l[g], l, g, r, t._required);
                        break;
                    case "custom":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._custom);
                        break;
                    case "groupRequired":
                        var C = "[" + r.validateAttribute + "*=" + l[g + 1] + "]",
                            b = m.find(C).eq(0);
                        b[0] != a[0] && (t._validateField(b, r, i), r.showArrow = !0), x = t._getErrorMessage(m, a, l[g], l, g, r, t._groupRequired), x && (v = !0), r.showArrow = !1;
                        break;
                    case "ajax":
                        x = t._ajax(a, l, g, r), x && (f = "load");
                        break;
                    case "minSize":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._minSize);
                        break;
                    case "maxSize":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._maxSize);
                        break;
                    case "min":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._min);
                        break;
                    case "max":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._max);
                        break;
                    case "past":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._past);
                        break;
                    case "future":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._future);
                        break;
                    case "dateRange":
                        var C = "[" + r.validateAttribute + "*=" + l[g + 1] + "]";
                        r.firstOfGroup = m.find(C).eq(0), r.secondOfGroup = m.find(C).eq(1), (r.firstOfGroup[0].value || r.secondOfGroup[0].value) && (x = t._getErrorMessage(m, a, l[g], l, g, r, t._dateRange)), x && (v = !0), r.showArrow = !1;
                        break;
                    case "dateTimeRange":
                        var C = "[" + r.validateAttribute + "*=" + l[g + 1] + "]";
                        r.firstOfGroup = m.find(C).eq(0), r.secondOfGroup = m.find(C).eq(1), (r.firstOfGroup[0].value || r.secondOfGroup[0].value) && (x = t._getErrorMessage(m, a, l[g], l, g, r, t._dateTimeRange)), x && (v = !0), r.showArrow = !1;
                        break;
                    case "maxCheckbox":
                        a = e(m.find("input[name='" + u + "']")), x = t._getErrorMessage(m, a, l[g], l, g, r, t._maxCheckbox);
                        break;
                    case "minCheckbox":
                        a = e(m.find("input[name='" + u + "']")), x = t._getErrorMessage(m, a, l[g], l, g, r, t._minCheckbox);
                        break;
                    case "equals":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._equals);
                        break;
                    case "funcCall":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._funcCall);
                        break;
                    case "creditCard":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._creditCard);
                        break;
                    case "condRequired":
                        x = t._getErrorMessage(m, a, l[g], l, g, r, t._condRequired), void 0 !== x && (v = !0)
                }
                var E = !1;
                if ("object" == typeof x) switch (x.status) {
                    case "_break":
                        E = !0;
                        break;
                    case "_error":
                        x = x.message;
                        break;
                    case "_error_no_prompt":
                        return !0
                }
                if (E) break;
                "string" == typeof x && (c += x + "<br/>", r.isError = !0, h++)
            } !v && !a.val() && a.val().length < 1 && (r.isError = !1);
            var T = a.prop("type"),
                F = a.data("promptPosition") || r.promptPosition;
            ("radio" == T || "checkbox" == T) && m.find("input[name='" + u + "']").length > 1 && (a = e("inline" === F ? m.find("input[name='" + u + "'][type!=hidden]:last") : m.find("input[name='" + u + "'][type!=hidden]:first")), r.showArrow = !1), a.is(":hidden") && r.prettySelect && (a = m.find("#" + r.usePrefix + t._jqSelector(a.attr("id")) + r.useSuffix)), r.isError && r.showPrompts ? t._showPrompt(a, c, f, !1, r) : d || t._closePrompt(a), d || a.trigger("jqv.field.result", [a, r.isError, c]);
            var k = e.inArray(a[0], r.InvalidFields);
            return -1 == k ? r.isError && r.InvalidFields.push(a[0]) : r.isError || r.InvalidFields.splice(k, 1), t._handleStatusCssClasses(a, r), r.isError && r.onFieldFailure && r.onFieldFailure(a), !r.isError && r.onFieldSuccess && r.onFieldSuccess(a), r.isError
        },
        _handleStatusCssClasses: function (e, t) {
            t.addSuccessCssClassToField && e.removeClass(t.addSuccessCssClassToField), t.addFailureCssClassToField && e.removeClass(t.addFailureCssClassToField), t.addSuccessCssClassToField && !t.isError && e.addClass(t.addSuccessCssClassToField), t.addFailureCssClassToField && t.isError && e.addClass(t.addFailureCssClassToField)
        },
        _getErrorMessage: function (a, r, i, o, s, n, l) {
            var d = jQuery.inArray(i, o);
            if ("custom" === i || "funcCall" === i) {
                var u = o[d + 1];
                i = i + "[" + u + "]", delete o[d]
            }
            var c, f = i,
                v = r.attr("data-validation-engine") ? r.attr("data-validation-engine") : r.attr("class"),
                p = v.split(" ");
            if (c = "future" == i || "past" == i || "maxCheckbox" == i || "minCheckbox" == i ? l(a, r, o, s, n) : l(r, o, s, n), void 0 != c) {
                var m = t._getCustomErrorMessage(e(r), p, f, n);
                m && (c = m)
            }
            return c
        },
        _getCustomErrorMessage: function (e, a, r, i) {
            var o = !1,
                s = /^custom\[.*\]$/.test(r) ? t._validityProp.custom : t._validityProp[r];
            if (void 0 != s && (o = e.attr("data-errormessage-" + s), void 0 != o)) return o;
            if (o = e.attr("data-errormessage"), void 0 != o) return o;
            var n = "#" + e.attr("id");
            if ("undefined" != typeof i.custom_error_messages[n] && "undefined" != typeof i.custom_error_messages[n][r]) o = i.custom_error_messages[n][r].message;
            else if (a.length > 0)
                for (var l = 0; l < a.length && a.length > 0; l++) {
                    var d = "." + a[l];
                    if ("undefined" != typeof i.custom_error_messages[d] && "undefined" != typeof i.custom_error_messages[d][r]) {
                        o = i.custom_error_messages[d][r].message;
                        break
                    }
                }
            return o || "undefined" == typeof i.custom_error_messages[r] || "undefined" == typeof i.custom_error_messages[r].message || (o = i.custom_error_messages[r].message), o
        },
        _validityProp: {
            required: "value-missing",
            custom: "custom-error",
            groupRequired: "value-missing",
            ajax: "custom-error",
            minSize: "range-underflow",
            maxSize: "range-overflow",
            min: "range-underflow",
            max: "range-overflow",
            past: "type-mismatch",
            future: "type-mismatch",
            dateRange: "type-mismatch",
            dateTimeRange: "type-mismatch",
            maxCheckbox: "range-overflow",
            minCheckbox: "range-underflow",
            equals: "pattern-mismatch",
            funcCall: "custom-error",
            creditCard: "pattern-mismatch",
            condRequired: "value-missing"
        },
        _required: function (t, a, r, i, o) {
            switch (t.prop("type")) {
                case "text":
                case "password":
                case "textarea":
                case "file":
                case "select-one":
                case "select-multiple":
                default:
                    var s = e.trim(t.val()),
                        n = e.trim(t.attr("data-validation-placeholder")),
                        l = e.trim(t.attr("placeholder"));
                    if (!s || n && s == n || l && s == l) return i.allrules[a[r]].alertText;
                    break;
                case "radio":
                case "checkbox":
                    if (o) {
                        if (!t.attr("checked")) return i.allrules[a[r]].alertTextCheckboxMultiple;
                        break
                    }
                    var d = t.closest("form, .validationEngineContainer"),
                        u = t.attr("name");
                    if (0 == d.find("input[name='" + u + "']:checked").length) return 1 == d.find("input[name='" + u + "']:visible").length ? i.allrules[a[r]].alertTextCheckboxe : i.allrules[a[r]].alertTextCheckboxMultiple
            }
        },
        _groupRequired: function (a, r, i, o) {
            var s = "[" + o.validateAttribute + "*=" + r[i + 1] + "]",
                n = !1;
            return a.closest("form, .validationEngineContainer").find(s).each(function () {
                return t._required(e(this), r, i, o) ? void 0 : (n = !0, !1)
            }), n ? void 0 : o.allrules[r[i]].alertText
        },
        _custom: function (e, t, a, r) {
            var i, o = t[a + 1],
                s = r.allrules[o];
            if (!s) return void alert("jqv:custom rule not found - " + o);
            if (s.regex) {
                var n = s.regex;
                if (!n) return void alert("jqv:custom regex not found - " + o);
                var l = new RegExp(n);
                if (!l.test(e.val())) return r.allrules[o].alertText
            } else {
                if (!s.func) return void alert("jqv:custom type not allowed " + o);
                if (i = s.func, "function" != typeof i) return void alert("jqv:custom parameter 'function' is no function - " + o);
                if (!i(e, t, a, r)) return r.allrules[o].alertText
            }
        },
        _funcCall: function (e, t, a, r) {
            var i, o = t[a + 1];
            if (o.indexOf(".") > -1) {
                for (var s = o.split("."), n = window; s.length;) n = n[s.shift()];
                i = n
            } else i = window[o] || r.customFunctions[o];
            return "function" == typeof i ? i(e, t, a, r) : void 0
        },
        _equals: function (t, a, r, i) {
            var o = a[r + 1];
            return t.val() != e("#" + o).val() ? i.allrules.equals.alertText : void 0
        },
        _maxSize: function (e, t, a, r) {
            var i = t[a + 1],
                o = e.val().length;
            if (o > i) {
                var s = r.allrules.maxSize;
                return s.alertText + i + s.alertText2
            }
        },
        _minSize: function (e, t, a, r) {
            var i = t[a + 1],
                o = e.val().length;
            if (i > o) {
                var s = r.allrules.minSize;
                return s.alertText + i + s.alertText2
            }
        },
        _min: function (e, t, a, r) {
            var i = parseFloat(t[a + 1]),
                o = parseFloat(e.val());
            if (i > o) {
                var s = r.allrules.min;
                return s.alertText2 ? s.alertText + i + s.alertText2 : s.alertText + i
            }
        },
        _max: function (e, t, a, r) {
            var i = parseFloat(t[a + 1]),
                o = parseFloat(e.val());
            if (o > i) {
                var s = r.allrules.max;
                return s.alertText2 ? s.alertText + i + s.alertText2 : s.alertText + i
            }
        },
        _past: function (a, r, i, o, s) {
            var n, l = i[o + 1],
                d = e(a.find("input[name='" + l.replace(/^#+/, "") + "']"));
            if ("now" == l.toLowerCase()) n = new Date;
            else if (void 0 != d.val()) {
                if (d.is(":disabled")) return;
                n = t._parseDate(d.val())
            } else n = t._parseDate(l);
            var u = t._parseDate(r.val());
            if (u > n) {
                var c = s.allrules.past;
                return c.alertText2 ? c.alertText + t._dateToString(n) + c.alertText2 : c.alertText + t._dateToString(n)
            }
        },
        _future: function (a, r, i, o, s) {
            var n, l = i[o + 1],
                d = e(a.find("input[name='" + l.replace(/^#+/, "") + "']"));
            if ("now" == l.toLowerCase()) n = new Date;
            else if (void 0 != d.val()) {
                if (d.is(":disabled")) return;
                n = t._parseDate(d.val())
            } else n = t._parseDate(l);
            var u = t._parseDate(r.val());
            if (n > u) {
                var c = s.allrules.future;
                return c.alertText2 ? c.alertText + t._dateToString(n) + c.alertText2 : c.alertText + t._dateToString(n)
            }
        },
        _isDate: function (e) {
            var t = new RegExp(/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$|^(?:(?:(?:0?[13578]|1[02])(\/|-)31)|(?:(?:0?[1,3-9]|1[0-2])(\/|-)(?:29|30)))(\/|-)(?:[1-9]\d\d\d|\d[1-9]\d\d|\d\d[1-9]\d|\d\d\d[1-9])$|^(?:(?:0?[1-9]|1[0-2])(\/|-)(?:0?[1-9]|1\d|2[0-8]))(\/|-)(?:[1-9]\d\d\d|\d[1-9]\d\d|\d\d[1-9]\d|\d\d\d[1-9])$|^(0?2(\/|-)29)(\/|-)(?:(?:0[48]00|[13579][26]00|[2468][048]00)|(?:\d\d)?(?:0[48]|[2468][048]|[13579][26]))$/);
            return t.test(e)
        },
        _isDateTime: function (e) {
            var t = new RegExp(/^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])\s+(1[012]|0?[1-9]){1}:(0?[1-5]|[0-6][0-9]){1}:(0?[0-6]|[0-6][0-9]){1}\s+(am|pm|AM|PM){1}$|^(?:(?:(?:0?[13578]|1[02])(\/|-)31)|(?:(?:0?[1,3-9]|1[0-2])(\/|-)(?:29|30)))(\/|-)(?:[1-9]\d\d\d|\d[1-9]\d\d|\d\d[1-9]\d|\d\d\d[1-9])$|^((1[012]|0?[1-9]){1}\/(0?[1-9]|[12][0-9]|3[01]){1}\/\d{2,4}\s+(1[012]|0?[1-9]){1}:(0?[1-5]|[0-6][0-9]){1}:(0?[0-6]|[0-6][0-9]){1}\s+(am|pm|AM|PM){1})$/);
            return t.test(e)
        },
        _dateCompare: function (e, t) {
            return new Date(e.toString()) < new Date(t.toString())
        },
        _dateRange: function (e, a, r, i) {
            return !i.firstOfGroup[0].value && i.secondOfGroup[0].value || i.firstOfGroup[0].value && !i.secondOfGroup[0].value ? i.allrules[a[r]].alertText + i.allrules[a[r]].alertText2 : t._isDate(i.firstOfGroup[0].value) && t._isDate(i.secondOfGroup[0].value) && t._dateCompare(i.firstOfGroup[0].value, i.secondOfGroup[0].value) ? void 0 : i.allrules[a[r]].alertText + i.allrules[a[r]].alertText2
        },
        _dateTimeRange: function (e, a, r, i) {
            return !i.firstOfGroup[0].value && i.secondOfGroup[0].value || i.firstOfGroup[0].value && !i.secondOfGroup[0].value ? i.allrules[a[r]].alertText + i.allrules[a[r]].alertText2 : t._isDateTime(i.firstOfGroup[0].value) && t._isDateTime(i.secondOfGroup[0].value) && t._dateCompare(i.firstOfGroup[0].value, i.secondOfGroup[0].value) ? void 0 : i.allrules[a[r]].alertText + i.allrules[a[r]].alertText2
        },
        _maxCheckbox: function (e, t, a, r, i) {
            var o = a[r + 1],
                s = t.attr("name"),
                n = e.find("input[name='" + s + "']:checked").length;
            return n > o ? (i.showArrow = !1, i.allrules.maxCheckbox.alertText2 ? i.allrules.maxCheckbox.alertText + " " + o + " " + i.allrules.maxCheckbox.alertText2 : i.allrules.maxCheckbox.alertText) : void 0
        },
        _minCheckbox: function (e, t, a, r, i) {
            var o = a[r + 1],
                s = t.attr("name"),
                n = e.find("input[name='" + s + "']:checked").length;
            return o > n ? (i.showArrow = !1, i.allrules.minCheckbox.alertText + " " + o + " " + i.allrules.minCheckbox.alertText2) : void 0
        },
        _creditCard: function (e, t, a, r) {
            var i = !1,
                o = e.val().replace(/ +/g, "").replace(/-+/g, ""),
                s = o.length;
            if (s >= 14 && 16 >= s && parseInt(o) > 0) {
                var n, l = 0,
                    a = s - 1,
                    d = 1,
                    u = new String;
                do n = parseInt(o.charAt(a)), u += d++ % 2 == 0 ? 2 * n : n; while (--a >= 0);
                for (a = 0; a < u.length; a++) l += parseInt(u.charAt(a));
                i = l % 10 == 0
            }
            return i ? void 0 : r.allrules.creditCard.alertText
        },
        _ajax: function (a, r, i, o) {
            var s = r[i + 1],
                n = o.allrules[s],
                l = n.extraData,
                d = n.extraDataDynamic,
                u = {
                    fieldId: a.attr("id"),
                    fieldValue: a.val()
                };
            if ("object" == typeof l) e.extend(u, l);
            else if ("string" == typeof l)
                for (var c = l.split("&"), i = 0; i < c.length; i++) {
                    var f = c[i].split("=");
                    f[0] && f[0] && (u[f[0]] = f[1])
                }
            if (d)
                for (var v = String(d).split(","), i = 0; i < v.length; i++) {
                    var p = v[i];
                    if (e(p).length) {
                        var m = a.closest("form, .validationEngineContainer").find(p).val();
                        p.replace("#", "") + "=" + escape(m);
                        u[p.replace("#", "")] = m
                    }
                }
            return "field" == o.eventTrigger && delete o.ajaxValidCache[a.attr("id")], o.isError || t._checkAjaxFieldStatus(a.attr("id"), o) ? void 0 : (e.ajax({
                type: o.ajaxFormValidationMethod,
                url: n.url,
                cache: !1,
                dataType: "json",
                data: u,
                field: a,
                rule: n,
                methods: t,
                options: o,
                beforeSend: function () { },
                error: function (e, a) {
                    t._ajaxError(e, a)
                },
                success: function (r) {
                    var i = r[0],
                        s = e("#" + i).eq(0);
                    if (1 == s.length) {
                        var l = r[1],
                            d = r[2];
                        if (l) {
                            if (o.ajaxValidCache[i] = !0, d) {
                                if (o.allrules[d]) {
                                    var u = o.allrules[d].alertTextOk;
                                    u && (d = u)
                                }
                            } else d = n.alertTextOk;
                            o.showPrompts && (d ? t._showPrompt(s, d, "pass", !0, o) : t._closePrompt(s)), "submit" == o.eventTrigger && a.closest("form").submit()
                        } else {
                            if (o.ajaxValidCache[i] = !1, o.isError = !0, d) {
                                if (o.allrules[d]) {
                                    var u = o.allrules[d].alertText;
                                    u && (d = u)
                                }
                            } else d = n.alertText;
                            o.showPrompts && t._showPrompt(s, d, "", !0, o)
                        }
                    }
                    s.trigger("jqv.field.result", [s, o.isError, d])
                }
            }), n.alertTextLoad)
        },
        _ajaxError: function (e, t) {
            0 == e.status && null == t ? alert("The page is not served from a server! ajax call failed") : "undefined" != typeof console && console.log("Ajax error: " + e.status + " " + t)
        },
        _dateToString: function (e) {
            return e.getFullYear() + "-" + (e.getMonth() + 1) + "-" + e.getDate()
        },
        _parseDate: function (e) {
            var t = e.split("-");
            return t == e && (t = e.split("/")), t == e ? (t = e.split("."), new Date(t[2], t[1] - 1, t[0])) : new Date(t[0], t[1] - 1, t[2])
        },
        _showPrompt: function (a, r, i, o, s, n) {
            a.data("jqv-prompt-at") instanceof jQuery ? a = a.data("jqv-prompt-at") : a.data("jqv-prompt-at") && (a = e(a.data("jqv-prompt-at")));
            var l = t._getPrompt(a);
            n && (l = !1), e.trim(r) && (l ? t._updatePrompt(a, l, r, i, o, s) : t._buildPrompt(a, r, i, o, s))
        },
        _buildPrompt: function (a, r, i, o, s) {
            var n = e("<div>");
            switch (n.addClass(t._getClassName(a.attr("id")) + "formError"), n.addClass("parentForm" + t._getClassName(a.closest("form, .validationEngineContainer").attr("id"))), n.addClass("formError"), i) {
                case "pass":
                    n.addClass("greenPopup");
                    break;
                case "load":
                    n.addClass("blackPopup")
            }
            o && n.addClass("ajaxed");
            var l = (e("<div>").addClass("formErrorContent").html(r).appendTo(n), a.data("promptPosition") || s.promptPosition);
            if (s.showArrow) {
                var d = e("<div>").addClass("formErrorArrow");
                if ("string" == typeof l) {
                    var u = l.indexOf(":"); -1 != u && (l = l.substring(0, u))
                }
                switch (l) {
                    case "bottomLeft":
                    case "bottomRight":
                        n.find(".formErrorContent").before(d), d.addClass("formErrorArrowBottom").html('<div class="line1"><!-- --></div><div class="line2"><!-- --></div><div class="line3"><!-- --></div><div class="line4"><!-- --></div><div class="line5"><!-- --></div><div class="line6"><!-- --></div><div class="line7"><!-- --></div><div class="line8"><!-- --></div><div class="line9"><!-- --></div><div class="line10"><!-- --></div>');
                        break;
                    case "topLeft":
                    case "topRight":
                        d.html('<div class="line10"><!-- --></div><div class="line9"><!-- --></div><div class="line8"><!-- --></div><div class="line7"><!-- --></div><div class="line6"><!-- --></div><div class="line5"><!-- --></div><div class="line4"><!-- --></div><div class="line3"><!-- --></div><div class="line2"><!-- --></div><div class="line1"><!-- --></div>'), n.append(d)
                }
            }
            s.addPromptClass && n.addClass(s.addPromptClass);
            var c = a.attr("data-required-class");
            if (void 0 !== c) n.addClass(c);
            else if (s.prettySelect && e("#" + a.attr("id")).next().is("select")) {
                var f = e("#" + a.attr("id").substr(s.usePrefix.length).substring(s.useSuffix.length)).attr("data-required-class");
                void 0 !== f && n.addClass(f)
            }
            n.css({
                opacity: 0
            }), "inline" === l ? (n.addClass("inline"), "undefined" != typeof a.attr("data-prompt-target") && e("#" + a.attr("data-prompt-target")).length > 0 ? n.appendTo(e("#" + a.attr("data-prompt-target"))) : a.after(n)) : a.before(n);
            var u = t._calculatePosition(a, n, s);
            return n.css({
                position: "inline" === l ? "relative" : "absolute",
                top: u.callerTopPosition,
                left: u.callerleftPosition,
                marginTop: u.marginTopSize,
                opacity: 0
            }).data("callerField", a), s.autoHidePrompt && setTimeout(function () {
                n.animate({
                    opacity: 0
                }, function () {
                    n.closest(".formErrorOuter").remove(), n.remove()
                })
            }, s.autoHideDelay), n.animate({
                opacity: 1
            })
        },
        _updatePrompt: function (e, a, r, i, o, s, n) {
            if (a) {
                "undefined" != typeof i && ("pass" == i ? a.addClass("greenPopup") : a.removeClass("greenPopup"), "load" == i ? a.addClass("blackPopup") : a.removeClass("blackPopup")), o ? a.addClass("ajaxed") : a.removeClass("ajaxed"), a.find(".formErrorContent").html(r);
                var l = t._calculatePosition(e, a, s),
                    d = {
                        top: l.callerTopPosition,
                        left: l.callerleftPosition,
                        marginTop: l.marginTopSize
                    };
                n ? a.css(d) : a.animate(d)
            }
        },
        _closePrompt: function (e) {
            var a = t._getPrompt(e);
            a && a.fadeTo("fast", 0, function () {
                a.parent(".formErrorOuter").remove(), a.remove()
            })
        },
        closePrompt: function (e) {
            return t._closePrompt(e)
        },
        _getPrompt: function (a) {
            var r = e(a).closest("form, .validationEngineContainer").attr("id"),
                i = t._getClassName(a.attr("id")) + "formError",
                o = e("." + t._escapeExpression(i) + ".parentForm" + t._getClassName(r))[0];
            return o ? e(o) : void 0
        },
        _escapeExpression: function (e) {
            return e.replace(/([#;&,\.\+\*\~':"\!\^$\[\]\(\)=>\|])/g, "\\$1")
        },
        isRTL: function (t) {
            var a = e(document),
                r = e("body"),
                i = t && t.hasClass("rtl") || t && "rtl" === (t.attr("dir") || "").toLowerCase() || a.hasClass("rtl") || "rtl" === (a.attr("dir") || "").toLowerCase() || r.hasClass("rtl") || "rtl" === (r.attr("dir") || "").toLowerCase();
            return Boolean(i)
        },
        _calculatePosition: function (e, t, a) {
            var r, i, o, s = e.width(),
                n = e.position().left,
                l = e.position().top,
                d = (e.height(), t.height());
            r = i = 0, o = -d;
            var u = e.data("promptPosition") || a.promptPosition,
                c = "",
                f = "",
                v = 0,
                p = 0;
            switch ("string" == typeof u && -1 != u.indexOf(":") && (c = u.substring(u.indexOf(":") + 1), u = u.substring(0, u.indexOf(":")), -1 != c.indexOf(",") && (f = c.substring(c.indexOf(",") + 1), c = c.substring(0, c.indexOf(",")), p = parseInt(f), isNaN(p) && (p = 0)), v = parseInt(c), isNaN(c) && (c = 0)), u) {
                default:
                case "topRight":
                    i += n + s - 30,
                r += l;
                    break;
                case "topLeft":
                    r += l,
                i += n;
                    break;
                case "centerRight":
                    r = l + 4,
                o = 0,
                i = n + e.outerWidth(!0) + 5;
                    break;
                case "centerLeft":
                    i = n - (t.width() + 2),
                r = l + 4,
                o = 0;
                    break;
                case "bottomLeft":
                    r = l + e.height() + 5,
                o = 0,
                i = n;
                    break;
                case "bottomRight":
                    i = n + s - 30,
                r = l + e.height() + 5,
                o = 0;
                    break;
                case "inline":
                    i = 0,
                r = 0,
                o = 0
            }
            return i += v, r += p, {
                callerTopPosition: (r+20) + "px",
                callerleftPosition: i + "px",
                marginTopSize: o + "px"
            }
        },
        _saveOptions: function (t, a) {
            if (e.validationEngineLanguage) var r = e.validationEngineLanguage.allRules;
            else e.error("jQuery.validationEngine rules are not loaded, plz add localization files to the page");
            e.validationEngine.defaults.allrules = r;
            var i = e.extend(!0, {}, e.validationEngine.defaults, a);
            return t.data("jqv", i), i
        },
        _getClassName: function (e) {
            return e ? e.replace(/:/g, "_").replace(/\./g, "_") : void 0
        },
        _jqSelector: function (e) {
            return e.replace(/([;&,\.\+\*\~':"\!\^#$%@\[\]\(\)=>\|])/g, "\\$1")
        },
        _condRequired: function (e, a, r, i) {
            var o, s;
            for (o = r + 1; o < a.length; o++)
                if (s = jQuery("#" + a[o]).first(), s.length && void 0 == t._required(s, ["required"], 0, i, !0)) return t._required(e, ["required"], 0, i)
        },
        _submitButtonClick: function (t) {
            var a = e(this),
                r = a.closest("form, .validationEngineContainer");
            r.data("jqv_submitButton", a.attr("id"))
        }
    };
    e.fn.validationEngine = function (a) {
        var r = e(this);
        return r[0] ? "string" == typeof a && "_" != a.charAt(0) && t[a] ? ("showPrompt" != a && "hide" != a && "hideAll" != a && t.init.apply(r), t[a].apply(r, Array.prototype.slice.call(arguments, 1))) : "object" != typeof a && a ? void e.error("Method " + a + " does not exist in jQuery.validationEngine") : (t.init.apply(r, arguments), t.attach.apply(r)) : r
    }, e.validationEngine = {
        fieldIdCounter: 0,
        defaults: {
            validationEventTrigger: "blur",
            scroll: !0,
            focusFirstField: !0,
            showPrompts: !0,
            validateNonVisibleFields: !0,
            promptPosition: "topLeft",
            bindMethod: "bind",
            inlineAjax: !1,
            ajaxFormValidation: !1,
            ajaxFormValidationURL: !1,
            ajaxFormValidationMethod: "get",
            onAjaxFormComplete: e.noop,
            onBeforeAjaxFormValidation: e.noop,
            onValidationComplete: !1,
            doNotShowAllErrosOnSubmit: !1,
            custom_error_messages: {},
            binded: !0,
            showArrow: !0,
            isError: !1,
            maxErrorsPerField: !1,
            ajaxValidCache: {},
            autoPositionUpdate: !1,
            InvalidFields: [],
            onFieldSuccess: !1,
            onFieldFailure: !1,
            onSuccess: !1,
            onFailure: !1,
            validateAttribute: "class",
            addSuccessCssClassToField: "",
            addFailureCssClassToField: "",
            autoHidePrompt: !1,
            autoHideDelay: 1e4,
            fadeDuration: .3,
            prettySelect: !1,
            addPromptClass: "",
            usePrefix: "",
            useSuffix: "",
            showOneMessage: !1
        }
    }, e(function () {
        e.validationEngine.defaults.promptPosition = t.isRTL() ? "topRight" : "topLeft"
    })
}(jQuery);