/*
 * Stellarnav.js 2.6.0
 * Responsive, lightweight, multi-level dropdown menu.
 * Copyright (c) 2018 Vinny Moreira - http://vinnymoreira.com
 * Released under the MIT license
 */
(function ($) {
    $.fn.stellarNav = function (options, width, breakpoint) {

        var $nav, $width, $breakpoint, $parentItems;
        nav = $(this);
        nav.fadeIn();
        width = $(window).width();

        // default settings
        var settings = $.extend({
            breakpoint: 768, // number in pixels to determine when the nav should turn mobile friendly
            sticky: false, // makes nav sticky on scroll (desktop only)
            openingSpeed: 250, // how fast the dropdown should open in milliseconds
            closingDelay: 250, // controls how long the dropdowns stay open for in milliseconds
            showArrows: true, // shows dropdown arrows next to the items that have sub menus			
            scrollbarFix: false // fixes horizontal scrollbar issue on very long navs
        }, options);

        return this.each(function () {
            if (settings.breakpoint) {
                breakpoint = settings.breakpoint;
            }

            // adds toggle button to li items that have children
            if (activeMenu && activeMenu.length > 0) {
                var path = window.location.pathname;
                path = path.replace(/\/$/, "");
                path = decodeURIComponent(path);

                if (!path) {
                    path = activeMenu.find("li:first-child a").attr("href");
                }

                activeMenu.find(" li:has(ul)").addClass("has-sub");
                activeMenu.find(" a").each(function () {
                    var href = $(this).attr('href');
                    if (path === href || "/" + path.split("/")[1] === href) {
                        $(this).closest("li a").addClass("active");
                        $(this).parents("li").addClass("active");
                    }
                });
            }

            // Makes nav sticky on scroll
            if (settings.sticky) {
                navPos = nav.offset().top;
                if (width >= breakpoint) {
                    $(window).on('scroll', function () {
                        if ($(window).scrollTop() > navPos) {
                            nav.addClass('fixed');
                        }
                        else {
                            nav.removeClass('fixed');
                        }
                    });
                }
            }

            if (!settings.showArrows) {
                nav.addClass('hide-arrows');
            }

            // opens and closes menu
            navbarToggle.on('click', function (e) {
                e.preventDefault();

                if ($(this).hasClass('open')) {
                    body.removeClass('panel-open');
                    $(this).removeClass('open');
                    panel.animate({ right: -260 });
                    content.animate({ right: 0 });
                }
                else {
                    body.addClass('panel-open');
                    $(this).addClass('open');
                    panel.animate({ right: 0 });
                    content.animate({ right: 260 });
                }
            });

            if (settings.scrollbarFix) {
                body.addClass('stellarnav-noscroll-x');
            }

            var resetTriggers = function () {
                nav.find('li').off('mouseenter');
                nav.find('li').off('mouseleave');

                // resets all the styles back to normal that are added on the desktop for the mega dropdown
                nav.find('li').each(function () {
                    $(this).removeClass("open");
                    $(this).find('ul').first().removeAttr('style');
                    $(this).find('ul').first().children().removeAttr('style');
                });
            }

            // defines top level items
            parentItems = nav.find('>ul>li');

            var setTriggers = function () {
                $(parentItems).each(function () {
                    if ($(this).hasClass('mega')) {
                        // mega dropdown
                        $(this).on('mouseenter', function () {
                            // setPosition(this);
                            $(this).find('ul').first().stop(true, true).slideDown(settings.openingSpeed);
                        });
                        $(this).on('mouseleave', function () {
                            $(this).find('ul').first().stop(true, true).slideUp(settings.openingSpeed);
                        });
                    } else {

                        // first-level
                        $(this).on('mouseenter', function () {
                            $(this).children('ul').stop(true, true).slideDown(settings.openingSpeed);
                        });
                        $(this).on('mouseleave', function () {
                            $(this).children('ul').stop(true, true).delay(settings.closingDelay).slideUp(settings.openingSpeed);
                        });

                        //// second level and below
                        //$(this).find('li.has-sub').on('mouseenter', function () {
                        //    $(this).children('ul').stop(true, true).slideDown(settings.openingSpeed);
                        //});
                        //$(this).find('li.has-sub').on('mouseleave', function () {
                        //    $(this).children('ul').stop(true, true).delay(settings.closingDelay).slideUp(settings.openingSpeed);
                        //});
                    }
                });
            }

            windowCheck();

            // check browser width in real-time
            function windowCheck() {
                if (browserWidth <= breakpoint) { // mobile/tablet nav                   
                    if (mobileMenu.html().trim().length < 1) {
                        resetTriggers();

                        nav.removeClass('desktop');
                        nav.addClass('mobile');

                        $(nav).appendTo(mobileMenu);
                        setHasSub();
                        $(navbarToggle, mobileMenu).show();

                        dekstopMenu.hide();
                    }

                    if (mobileSocialIcons.is(':empty'))
                        $(header).find(socialIcons).clone().appendTo(mobileSocialIcons);

                } else { // desktop nav                   

                    nav.addClass('desktop');
                    if (dekstopMenu.html().trim().length < 1) {
                        $(nav).appendTo(dekstopMenu);

                        nav.removeClass('mobile');

                        body.removeClass('panel-open');
                        navbarToggle.removeClass('open');

                        if (panel.css("right") == "0px") {
                            panel.css({ right: -260 });
                        }

                        if (content.css("right") == "260px") {
                            content.css({ right: 0 });
                        }

                        mobileSocialIcons.empty();
                        $(navbarToggle, mobileMenu).hide();

                        nav.find(".dd-toggle").remove();
                    }

                    resetTriggers();
                    setTriggers();

                    if (!dekstopMenu.is(':visible')) {
                        dekstopMenu.show();
                    }

                    // ana men�leri gizlemek istiyorsan a�
                    // nav.find(".categories .has-sub ul").remove();
                    nav.find(">ul>li li.has-sub").removeClass("has-sub");

                    if (nav.hasClass('active')) {
                        nav.removeClass('active');
                    }

                    // // mega dropdown defines the mega dropdown width to be the same as nav width
                    if (parentItems.hasClass('mega')) {
                        navWidth = 0;

                        $(parentItems).each(function () {
                            // calculates the nav width based on the sum of all top-level items
                            navWidth += $(this)[0].getBoundingClientRect().width;
                            navWidth = Math.round(navWidth);

                            if ($(this).hasClass('mega')) {
                                // left aligns mega dropdown with nav
                                $(this).find('ul').first().css({ 'left': 0, 'right': 0, 'margin': '0px auto' });

                                // gets the data-column attribute and divides the columns equally
                                numCols = $(this).attr('data-columns');
                                if (numCols == 2) {
                                    $(this).find('li.has-sub').width('50%');
                                } else if (numCols == 3) {
                                    $(this).find('ul').first().children().width('33.33%');
                                } else if (numCols == 4) {
                                    $(this).find('ul').first().children().width('25%');
                                } else if (numCols == 5) {
                                    $(this).find('ul').first().children().width('20%');
                                } else if (numCols == 6) {
                                    $(this).find('ul').first().children().width('16.66%');
                                } else if (numCols == 7) {
                                    $(this).find('ul').first().children().width('14.28%');
                                } else if (numCols == 8) {
                                    $(this).find('ul').first().children().width('12.5%');
                                } else {
                                    // defaults to 4 column
                                    $(this).find('ul').first().children().width('25%');
                                }
                            }
                        });

                        nav.find('li.mega > ul').css({ 'max-width': navWidth });
                    }
                    // end mega dropdown

                } // end desktop nav
            } // windowCheck()

            $(window).on('resize', function () {
                windowCheck();
            });
        });

        function setHasSub() {

            // adds toggle button to li items that have children
            nav.find('li a').each(function () {
                if ($(this).next().length > 0) {
                    $(this).parent('li').addClass('has-sub').append('<a class="dd-toggle" href="javascript:void(0)"><i class="fa fa-plus none"></i></a>');
                }
            });

            // expands the dropdown menu on each click
            nav.find('li .dd-toggle').on('click', function (e) {
                e.preventDefault();
                //$(this).parent('li').children('ul').stop(true, true).slideToggle(settings.openingSpeed);
                //$(this).parent('li').toggleClass('open');

                if ($(this).parent('li').hasClass('open')) {
                    $(this).parent('li').children('ul').slideUp();
                    $(this).parent('li').removeClass('open');
                }
                else {
                    nav.find('ul').not($(this).parents('ul')).slideUp();
                    nav.find('li').not($(this).parents('li')).removeClass('open');

                    $(this).parent('li').children('ul').slideDown();
                    $(this).parent('li').addClass('open');
                }
            });
        }
    }
}(jQuery));