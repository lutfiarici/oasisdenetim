﻿var body = $("body");
var header = $("header");
var main = $("main");
var footer = $("footer");
var panel = $("#panel");
var kvkk = $("#kvkk");
var toTop = $("#to-top");
var content = $("header, main, footer");
var dekstopMenu = $(".dekstop-menu");
var mobileMenu = $(".mobile-menu");
var navbarToggle = $(".navbar-toggle");
var activeMenu = $(".active-menu");
var socialIcons = $("ul.social-icons");
var mobileSocialIcons = $(".mobile-social-icons");
var whatsappInfo = $(".whatsapp-info");
var sidebar = $(".sidebar");
var cardList = $(".row.card-list");
var preloader = $('.preloader-wrapper');
var prev_button = "<i class='mbri-arrow-prev none'></i>";
var next_button = "<i class='mbri-arrow-next none'></i>";
var prev_button2 = "<span class='mbri-left none'></span>";
var next_button2 = "<span class='mbri-right none'></span>";
var LangID = parseInt(body.attr("data-LangID"));
var browserWidth = window.innerWidth;
var breakpoint = 1199;

$(window).on('resize', function () {
    browserWidth = window.innerWidth;
});
