﻿$(function () {
    headerFixed();

    new WOW().init();
    $(".lazy").lazy();

    $(".stellarnav").stellarNav({
        breakpoint: breakpoint
    });

    if (sidebar.length > 0) {
        if (cardList.length > 0) {
            if (body.hasClass("news")) {
                cardList.find(".cols").removeClass("col-lg-4").addClass("col-lg-6");
            }
            else if (body.hasClass("reference")) {
                cardList.find(".cols").removeClass("col-lg-2").addClass("col-lg-3");
            }
            else {
                cardList.find(".cols").removeClass("col-lg-3").addClass("col-lg-4");
            }
        }
    }

    $("#txt-search").keypress(function (e) {
        if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
            search();
            return false;
        } else {
            return true;
        }
    });

    $(".search-open").on('click', function (e) {
        e.preventDefault();
        body.addClass('overflow-hidden');
        $(".search-place").slideDown();
        $("#txt-search").focus();
    });

    $(".search-close").on('click', function () {
        body.removeClass('overflow-hidden');
        $(".search-place").slideUp();
    });

    $('#btn-search').on('click', function () {
        search();
    });

    $('.close').click(function () {
        $('.alert').hide();
    });

    $('.btn.validate').on('click', function () {
        var forms = $(this).parents("form");
        var forms_name = forms;
        if (forms.attr("id")) {
            forms_name = "#" + forms.attr("id");
        }
        var validater = $(forms_name).validationEngine('validate');
        return validater;
    });

    $('.custom-file-input').change(function () {
        $this = $(this);
        var $label = $('.custom-file-label');
        if ($this.val().length == 0) {
            $label.text($label.attr("data-text"));
        } else {
            $label.text($this.val().split('\\')[2]);
        }
    });

    $(".faq-title").on('click', function (event) {
        event.preventDefault();
        $(".faq-title.active").removeClass('active');
        $(this).toggleClass('active').next().slideToggle(500).siblings('.faq-content').slideUp();
    });

    $("#btn-newsletter").on('click', function () {

        var email = $("#txt-newsletter");
        email.removeAttr('style');

        if (checkEmail(email.val())) {
            ajaxRequest("POST", "JSON", "/Other/Newsletter", { email: email.val() }, false,
                function (response) {
                    if (response.isError) {
                        toastrMsg(response.msj, 'error', '');
                    }
                    else {
                        toastrMsg(response.msj, 'success', pageUrl);
                    }
                }
            );
        }
        else {
            email.css('border', '1px solid #fc6f6f');
            email.focus();
        }
    });

    $(".btn-rating").on('click', (function (e) {
        var previous_value = $("#Point").val();
        var selected_value = $(this).attr("data-attr");
        $("#Point").val(selected_value);

        //$(".selected-rating").empty();
        //$(".selected-rating").html(selected_value);

        for (i = 1; i <= selected_value; ++i) {
            $("#rating-star-" + i).toggleClass('btn-warning');
            $("#rating-star-" + i).toggleClass('btn-default');
        }

        for (ix = 1; ix <= previous_value; ++ix) {
            $("#rating-star-" + ix).toggleClass('btn-warning');
            $("#rating-star-" + ix).toggleClass('btn-default');
        }

    }));

    $("#languages").on('change', function () {
        var link = $(this).val();
        if (link && link != "") {
            window.location.href = link;
        }
    });
	
    if ($(".homepagePopup").length > 0) {
        /*$.fancybox.open({
            src: '.homepagePopup',
            type: 'inline'
        });
		*/
		var $elem = $(".homepagePopup");
		var content = $elem.html();
		$elem.remove();
		$.fancybox.open(content);
		
    };

    $(".btn-sidebar").click(function () {
        $(".sidebar-content").slideToggle(500);
    });

    toTop.click(function () {
        goScrollTop(0);
    });

    fullHeight();
    $(window).resize(function () {
        fullHeight();
    });
});

$(window).on('load', function () {
    if (sidebar.length > 0) {
        $(".sidebar-inner").scrollChaser({
            wrapper: '.row.mains',
            offsetTop: 100,
            offsetBottom: 30
        });
    }
    loadingClose();
    owl_carousel();    

    var url = $(location).attr('href');
    if (url.indexOf("#") != -1) {
        var id = url.split("#");
        if (id.length > 0 && id[id.length - 1] != "") {
            scrollTop2(id[id.length - 1]);
        }
    }

    $(".go").on('click', function () {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            scrollTop2(this.hash.replace('#', '').replace('.', ''));
            return false;
        }
    });
});

function owl_carousel() {
    $('.slider').owlCarousel({
        items: 1,
        margin: 0,
        autoHeight: true,
        nav: true,
        loop: true,
        lazyLoad: false,
        autoplay: false,
        autoplayTimeout: 6000,
        smartSpeed: 2000,
        autoplayHoverPause: true,
        navText: [prev_button, next_button]
    });

    $('.parallax-slider').owlCarousel({
        items: 1,
        margin: 0,
        autoHeight: true,
        nav: false,
        autoplay: false,
        autoplayTimeout: 3000,
        smartSpeed: 2000,
        autoplayHoverPause: true
    });

    $('.products-slider').owlCarousel({
        items: 4,
        margin: 30,
        loop: true,
        autoHeight: false,
        nav: true,
        dots: false,
        lazyLoad: true,
        autoplay: false,
        navText: [prev_button, next_button],
        responsiveClass: true,
        responsive: {
            0: { items: 1, margin: 0 },
            376: { items: 2 },
            768: { items: 3 },
            992: { items: 4 }
        }
    });

    $('.news-slider').owlCarousel({
        items: 3,
        margin: 30,
        loop: true,
        autoHeight: true,
        nav: true,
        dots: false,
        lazyLoad: true,
        autoplay: false,
        navText: [prev_button, next_button],
        responsiveClass: true,
        responsive: {
            0: { items: 1 },
            415: { items: 2 },
            992: { items: 3 }
        }
    });

    $('.reference-slider').owlCarousel({
        items: 6,
        margin: 30,
        loop: true,
        autoHeight: true,
        nav: true,
        dots: false,
        lazyLoad: true,
        autoplay: false,
        navText: [prev_button, next_button],
        responsiveClass: true,
        responsive: {
            0: { items: 2 },
            376: { items: 3 },
            768: { items: 4 },
            992: { items: 6 }
        }
    });

    $('.post-image').owlCarousel({
        items: 1,
        margin: 0,
        autoHeight: true,
        nav: true,
        autoplay: false,
        lazyLoad: true,
        autoplayTimeout: 3000,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        autoplayHoverPause: true,
        navText: [prev_button, next_button]
    });

    $('.comments-slider').owlCarousel({
        items: 1,
        margin: 0,
        autoHeight: false,
        nav: true,
        dots: false,
        autoplay: false,
        autoplayTimeout: 3000,
        smartSpeed: 2000,
        animateOut: 'fadeOut',
        animateIn: 'fadeIn',
        autoplayHoverPause: true,
        navText: [prev_button2, next_button2]
    });

    var sync1 = $("#sync1");
    var sync2 = $("#sync2");
    if (sync1 && sync2) {
        var slidesPerPage = 4;
        var syncedSecondary = true;

        sync1.owlCarousel({
            items: 1,
            slideSpeed: 2000,
            nav: false,
            autoplay: false,
            dots: true,
            loop: true,
            lazyLoad: true,
            responsiveRefreshRate: 200,
            navText: [prev_button, next_button]
        }).on('changed.owl.carousel', syncPosition);

        sync2.on('initialized.owl.carousel', function () {
            sync2.find(".owl-item").eq(0).addClass("current");
        }).owlCarousel({
            items: slidesPerPage,
            dots: false,
            nav: true,
            lazyLoad: true,
            margin: 10,
            smartSpeed: 200,
            slideSpeed: 500,
            slideBy: slidesPerPage,
            responsiveRefreshRate: 100,
            navText: [prev_button, next_button]
        }).on('changed.owl.carousel', syncPosition2);

        sync2.on("click", ".owl-item", function (e) {
            e.preventDefault();
            var number = $(this).index();
            sync1.data('owl.carousel').to(number, 300, true);
        });
    }

    function syncPosition(el) {
        var count = el.item.count - 1;
        var current = Math.round(el.item.index - (el.item.count / 2) - .5);

        if (current < 0) {
            current = count;
        }
        if (current > count) {
            current = 0;
        }
        sync2
            .find(".owl-item")
            .removeClass("current")
            .eq(current)
            .addClass("current");
        var onscreen = sync2.find('.owl-item.active').length - 1;
        var start = sync2.find('.owl-item.active').first().index();
        var end = sync2.find('.owl-item.active').last().index();

        if (current > end) {
            sync2.data('owl.carousel').to(current, 100, true);
        }
        if (current < start) {
            sync2.data('owl.carousel').to(current - onscreen, 100, true);
        }
    }

    function syncPosition2(el) {
        if (syncedSecondary) {
            var number = el.item.index;
            sync1.data('owl.carousel').to(number, 100, true);
        }
    }
}

function headerFixed() {
    if ($(document).scrollTop() > header.height()) {
        header.addClass('fixed-header animated fadeInDown');
    }

    $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll >= header.height() && !body.hasClass("overflow-hidden")) {
            header.addClass('fixed-header animated fadeInDown');
            body.css('padding-top', header.height());
            toTop.fadeIn(100);
        }
        else {
            header.removeClass('fixed-header animated fadeInDown');
            body.css('padding-top', 0);
            toTop.fadeOut(100);
        }
    });
}

function search() {
    if (typeof LangID !== 'undefined' && LangID !== null && LangID > 0) {
        var txtsearch = $('#txt-search');
        txtsearch.removeAttr('style');
        if (txtsearch.val().length > 0) {
            window.location = "/search/" + LangID + "/" + txtsearch.val();
        }
        else {
            txtsearch.css('border-bottom', '2px solid #da251c');
            txtsearch.focus();
        }
    }
}

function loadingClose() {
    setTimeout(function () {
        preloader.fadeOut();
    }, 400);
}

function loadingOpen() {
    preloader.show();
}

function scrollTop(target) {
    if (target.length) {
        goScrollTop($(target).offset().top);
    }
}
function scrollTop2(a) {
    var target = $('#' + a);
    if (target.length) {
        scrollTop(target);
    }
    else {
        target = $('.' + a);
        if (target.length) {
            scrollTop(target);
        }
    }
}
function goScrollTop(offsetTop) {
    $('html, body').animate({
        scrollTop: offsetTop - (header.height() / 2)
    }, 500);
    return false;
}
var fullHeight = function () {
    $('.js-fullheight').css('height', $(window).height());
};