﻿$(function () {
    setDatetime();

    var EhliyetSinifi = $('#form_EhliyetSinifi');
    EhliyetSinifi.selectpicker();

    var Ehliyet = $('#form_Ehliyet');
    var EhliyetSinifiSinif = $(".EhliyetSinifi");
    GosterGizle($("input[name='form.Ehliyet']:checked").val(), EhliyetSinifiSinif);
    Ehliyet.change(function () {
        GosterGizle($(this).val(), EhliyetSinifiSinif);
    });

    var Cinsiyet = $("input[name='form.Cinsiyet']");
    var AskerlikDurumuSinif = $(".AskerlikDurumu");
    GosterGizle($("input[name='form.Cinsiyet']:checked").val(), AskerlikDurumuSinif);
    Cinsiyet.change(function () {
        GosterGizle($(this).val(), AskerlikDurumuSinif);
    });

    var SaglikDurumu = $('#form_SaglikDurumu');
    var SaglikDurumuSinif = $(".SaglikDurumuDetay");
    GosterGizle(SaglikDurumu.val(), SaglikDurumuSinif);
    SaglikDurumu.change(function () {
        GosterGizle($(this).val(), SaglikDurumuSinif);
    });

    function GosterGizle(val, sinif) {
        var val = parseInt(val);
        if (val == 0) {
            sinif.hide();
        }
        else {
            sinif.show();
        }
    }

    // YABANCI DİLLER İŞLEMLERİ
    var genelDiv = "YabanciDiller";
    var disDiv = $("#" + genelDiv);
    var icDiv = $('.' + genelDiv);
    $(".addRow").click(function () {
        var icerik = icDiv.html().
                     replace('<span class="dot">:</span>', '<a href="javascript:void(0);" class="remRow dot" title="' + kaldir + '"><i class="fas fa-times none"></i></a>');

        disDiv.append('<div class="form-group row align-items-center mb-0 ' + genelDiv + '">' + icerik + '</div>');
        var itemSayisi = $(".YabanciDiller").length;
        nameDuzelt(".YabanciDiller", itemSayisi - 1);
        setDatetime();
    });

    disDiv.on('click', '.remRow', function () {
        var itemSayisi = $(".YabanciDiller").length;
        $(this).closest('.' + genelDiv).remove();
        nameDuzelt(".YabanciDiller", itemSayisi - 1);
    });
    // YABANCI DİLLER İŞLEMLERİ

    // İŞ TECRÜBESİ İŞLEMLERİ
    var IsTecrubesiVarmi = $("input[name='form.IsTecrubesiVarmi']");
    var IsTecrubeleriSinif = $("#IsTecrubeleri");
    var IsTecrubesiVarmiVal = $("input[name='form.IsTecrubesiVarmi']:checked").val();
    GosterGizle(IsTecrubesiVarmiVal, IsTecrubeleriSinif);
    isTecrubesiIslemYap(IsTecrubesiVarmiVal);
    IsTecrubesiVarmi.change(function () {
        GosterGizle($(this).val(), IsTecrubeleriSinif);
        isTecrubesiIslemYap($(this).val());
    });

    function isTecrubesiIslemYap(val) {
        var val = parseInt(val);
        if (val == 1) {
            $(".IsTecrubeleriEkle").show();
            var genelDiv2 = "IsTecrubeleri";
            var disDiv2 = $("#" + genelDiv2);
            var icDiv2 = $('.' + genelDiv2);
            $(".addRow2").click(function () {
                var icerik = icDiv2.html().
                             replace('<div class="form-group row IsTecrubeleriKaldir" style="display:none">', '<div class="form-group row IsTecrubeleriKaldir">');

                disDiv2.append('<div class="' + genelDiv2 + '">' + icerik + '</div>');
                var itemSayisi = $(".IsTecrubeleri").length;
                nameDuzelt(".IsTecrubeleri", itemSayisi - 1);
                setDatetime();
            });

            disDiv2.on('click', '.remRow2', function () {
                var itemSayisi = $(".IsTecrubeleri").length;
                $(this).closest('.' + genelDiv2).remove();
                nameDuzelt(".IsTecrubeleri", itemSayisi - 1);
            });
        }
        else {
            $(".IsTecrubeleriEkle").hide();
        }
    }
    // İŞ TECRÜBESİ İŞLEMLERİ

    // REFERANS İŞLEMLERİ
    var genelDiv3 = "Referanslar";
    var disDiv3 = $("#" + genelDiv3);
    var icDiv3 = $('.' + genelDiv3);
    $(".addRow3").click(function () {
        var icerik = icDiv3.html().
                     replace('<div class="form-group row ReferanslarKaldir" style="display:none">', '<div class="form-group row ReferanslarKaldir">');

        disDiv3.append('<div class="' + genelDiv3 + '">' + icerik + '</div>');
        var itemSayisi = $(".Referanslar").length;
        nameDuzelt(".Referanslar", itemSayisi - 1);
        setDatetime();
    });

    disDiv3.on('click', '.remRow3', function () {
        var itemSayisi = $(".Referanslar").length;
        $(this).closest('.' + genelDiv3).remove();
        nameDuzelt(".Referanslar", itemSayisi - 1);
    });
    // REFERANS İŞLEMLERİ

    function nameDuzelt(sinif, itemSayisi) {
        $(sinif).each(function (index) {
            $(this).find('input,select').each(function () {
                var a = $(this);
                var b = a.attr('type');
                var c = a.attr('name');
                var sayi = c.match(/\d+/);
                var d = c.replace(sayi, index);
                a.attr('name', d);
                a.attr('id', d);

                if (index == itemSayisi) {
                    if (b == "text") {
                        a.attr('value', '');
                    }
                    else {
                        a.find("option:selected").removeAttr("selected");
                    }
                }
            });
        });
    }

    function setDatetime() {
       $('.datepicker').each(function () {
            $(this).removeClass("hasDatepicker");
        })     
    }

 $(document).on("focus", ".datepicker", function(){
$(this).datepicker({
                dateFormat: 'dd/mm/yy',
                changeMonth: true,
                changeYear: true,
                yearRange: "-100:+0",
            });
    }); 


});