﻿var pageUrl = window.location.href;

var controllerName = function () {
    var url = window.location.pathname.split("/");
    return url[2];
}

var isMobile = {
    Android: function () {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function () {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function () {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function () {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function () {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function () {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};

var imgRegex = /(\.jpg|\.jpeg|\.png|\.gif|\.bmp|\.ico|\.tif|\.tiff|\.svg|\.webp)$/i;

function toastrMsg(_msg, _type, _redirecturl) {
    toastr.options = {
        'closeButton': true,
        'debug': false,
        'positionClass': 'toast-top-right',
        'onclick': null,
        'showDuration': '300',
        'hideDuration': '1000',
        'timeOut': '5000',
        'extendedTimeOut': '1000',
        'showEasing': 'swing',
        'hideEasing': 'linear',
        'showMethod': 'fadeIn',
        'hideMethod': 'fadeOut',
        'progressBar': true
    };

    if (_redirecturl != '' && _redirecturl != null)
        toastr.options.onHidden = function () { window.location.href = _redirecturl };

    if (_type == '' || _type == null) toastr.error(_msg);
    else toastr[_type](_msg);
}

function openWindow(query, w, h, scroll) {
    var l = (screen.width - w) / 2;
    var t = (screen.height - h) / 2;

    winprops = 'resizable=0, height=' + h + ',width=' + w + ',top=' + t + ',left=' + l + 'w';
    if (scroll) winprops += ',scrollbars=1';
    var f = window.open(query, "_blank", winprops);
}

function openWindow2(windowWidth, windowHeight, windowUri) {
    var centerWidth = (window.screen.width - windowWidth) / 2;
    var centerHeight = (window.screen.height - windowHeight) / 2;
    window.open(windowUri, 'Bilgi', 'scrollbars=no,menubar=no,height=' + windowHeight + ',width=' + windowWidth + ',left=' + centerWidth + ',top=' + centerHeight + ',resizable=yes,toolbar=no,location=no,status=no');
}

function setLocation(url) {
    window.location.href = url;
}

function checkEmail(email) {
    var filter = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;

    if (!filter.test(email)) {
        return false;
    }
    else {
        return true;
    }
}

function getQueryStr(key) {
    var reParam = new RegExp('(?:[\?&]|&)' + key + '=([^&]+)', 'i');
    var match = window.location.search.match(reParam);
    return (match && match.length > 1) ? decodeURIComponent(match[1]) : null;
};

function removeQueryStr(key, url) {

    url = findUrl(url);

    var arr = key.split(',');
    $.each(arr, function (index, value) {
        url = _removeQueryStr(value, url);
    });

    return url;
};

function _removeQueryStr(key, url) {
    return url.replace(new RegExp('[?&]' + key + '=[^&#]*(#.*)?$'), '$1').replace(new RegExp('([?&])' + key + '=[^&]*&'), '$1');
};

function updateQueryStr(key, value, remove, url) {
    url = findUrl(url);
    if (typeof remove !== 'undefined' && remove !== null) {
        url = removeQueryStr(remove);
    }

    var re = new RegExp("([?&])" + key + "=.*?(&|#|$)(.*)", "gi"),
        hash;

    if (re.test(url)) {
        if (typeof value !== 'undefined' && value !== null)
            return url.replace(re, '$1' + key + "=" + value + '$2$3');
        else {
            hash = url.split('#');
            url = hash[0].replace(re, '$1$3').replace(/(&|\?)$/, '');
            if (typeof hash[1] !== 'undefined' && hash[1] !== null)
                url += '#' + hash[1];
            return url;
        }
    }
    else {
        if (typeof value !== 'undefined' && value !== null) {
            var separator = url.indexOf('?') !== -1 ? '&' : '?';
            hash = url.split('#');
            url = hash[0] + separator + key + '=' + value;
            if (typeof hash[1] !== 'undefined' && hash[1] !== null)
                url += '#' + hash[1];
            return url;
        }
        else
            return url;
    }
};

function findUrl(url) {
    if (typeof url !== 'undefined' && url !== null) {
        return url;
    }
    return window.location.href;
};

var onlyNumber = function (evt) {
    evt = (evt) ? evt : window.event
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false
    }
    return true
}

var numberControl = function (olay, b) {
    var charCode;
    if (window.event) {
        charCode = olay.keyCode
    } else if (olay.which) {
        charCode = olay.which;
    }
    if (charCode == 8) {
        return true;
    }
    if (b == 1) {
        if (charCode == 44) {
            return true;
        }
        //if (charCode == 46) {
        //    return true;
        //}
    }
    if (charCode < 48 || charCode > 57) {
        charCode.keyCode = 0;
        return false;
    }
    else {
        return true;
    }
}

var characterRestriction = function (txtMsg, CharLength, indicator) {
    chars = txtMsg.value.length;
    jQuery(indicator).html(CharLength - chars);
    if (chars > CharLength) {
        txtMsg.value = txtMsg.value.substring(0, CharLength);
        //Text in textbox was trimmed, re-set indicator value to 0      
        jQuery(indicator).html(0);
    }
}

var ayrac = ".";
function priceDot(deger) {
    var de = /(\d+)(\d{3})/;
    while (de.test(deger)) {
        deger = eval("deger.replace(de,'$1" + ayrac + "$2')");
    }
    return deger;
}
function clearDot(deger) {
    var de = eval("/\\" + ayrac + "/g");
    return deger.replace(de, "");
}

function priceField(object) {
    deger = object.value;
    var sondegeri = clearDot(deger);
    if (sondegeri.length > 9) {
        sondegeri = sondegeri.substring(0, 9);
    }
    if (!isNaN(parseInt(sondegeri, 10))) {
        sondegeri = parseInt(sondegeri, 10).toString();
    } else {
        object.value = "";
        object.focus();
        return;
    }
    object.value = priceDot(sondegeri);
}

function priceFormat(deger) {
    var sondegeri = clearDot(deger);
    if (sondegeri.length > 9) {
        sondegeri = sondegeri.substring(0, 9);
    }
    if (!isNaN(parseInt(sondegeri, 10))) {
        sondegeri = parseInt(sondegeri, 10).toString();
    }
    return priceDot(sondegeri);
}

function ajaxRequest(ajaxType, dataType, urlStr, dataStr, isLoading, fn_SuccessCallBack, fn_CompleteCallBack, fn_ErrorCallBack) {
    $.ajax({
        cache: false,
        dataType: dataType,
        type: ajaxType,
        url: urlStr,
        data: dataStr,
        beforeSend: function () {
            if (isLoading) {
                loadingOpen();
            }
        },
        success: function (response) {
            fn_SuccessCallBack(response);
        },
        error: function (xhr, ajaxOptions, thrownError) {
            if (fn_ErrorCallBack) {
                fn_ErrorCallBack(xhr);
            }
            else {
                alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        },
        complete: function () {
            if (isLoading) {
                loadingClose();
            }
            if (fn_CompleteCallBack) {
                fn_CompleteCallBack();
            }
        }
    });
}

function AllImageReplace() {
    var images = document.getElementsByTagName('img');
    for (var i = 0; i < images.length; i++) {
        var img = images[i];

        if (img.src.toLowerCase().indexOf("/uploads/") > -1) {
            if (img.src.indexOf("https://www.mavitasprefabrik.com.tr") < 0) {
                img.src = "https://www.mavitasprefabrik.com.tr" + img.getAttribute("src");
            }
        }
    }
}

function siteUrl() {
    var loc = window.location;
    var pathName = loc.pathname.substring(0, loc.pathname.lastIndexOf('/') + 1);
    return loc.href.substring(0, loc.href.length - ((loc.pathname + loc.search + loc.hash).length - (pathName.length - 1)));
}
