$('.btn_random_pass').on('click', function () {
    var txtbox = $(this).attr("data-txtbox");
    $(txtbox).val(RastgeleUret());
});

function RastgeleUret() {
    var ret = "";
    for (var i = 0; i < 10; i++) {
        if (i < 2)
            ret += RandKKarakter();
        else if (i < 3)
            ret += RandBKarakter();
        else if (i < 4)
            ret += RandOzelKarakter();
        else if (i < 5)
            ret += RandSayi();
        else if (i < 11)
            ret += RandKarisik();
    }
    return ret;
}
var kkarakter = "abcdefghijkmnpqrstuvwxwz";
var bkarakter = "ABCDEFGHIJKMNPQRSTUYVWXZ";
var sayi = "1234567890";
var ozelkarakter = "@#?!&_";
var karisik = kkarakter + ozelkarakter + sayi + ozelkarakter + bkarakter;

function RandKKarakter() { return kkarakter.charAt(Math.floor(Math.random() * kkarakter.length)) }
function RandBKarakter() { return bkarakter.charAt(Math.floor(Math.random() * bkarakter.length)) }
function RandSayi() { return sayi.charAt(Math.floor(Math.random() * sayi.length)) }
function RandOzelKarakter() { return ozelkarakter.charAt(Math.floor(Math.random() * ozelkarakter.length)) }
function RandKarisik() { return kkarakter.charAt(Math.floor(Math.random() * kkarakter.length)) }