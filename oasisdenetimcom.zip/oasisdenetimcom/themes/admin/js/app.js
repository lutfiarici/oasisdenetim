var App = function () {
    var page, pageContent, header, footer, sidebar, sScroll, sidebarAlt, sScrollAlt;
    var uiInit = function () {
        page = $('#page-container');
        pageContent = $('#page-content');
        header = $('header');
        footer = $('#page-content + footer');

        sidebar = $('#sidebar');
        sScroll = $('#sidebar-scroll');

        sidebarAlt = $('#sidebar-alt');
        sScrollAlt = $('#sidebar-alt-scroll');

        // Initialize sidebars functionality
        handleSidebar('init');

        // Sidebar navigation functionality
        handleNav();

        // Interactive blocks functionality
        interactiveBlocks();

        // Scroll to top functionality
        scrollToTop();

        // Template Options, change features
        templateOptions();

        // Resize #page-content to fill empty space if exists (also add it to resize and orientationchange events)
        resizePageContent();
        $(window).resize(function () { resizePageContent(); });
        $(window).bind('orientationchange', resizePageContent);

        // Initialize tabs
        $('[data-toggle="tabs"] a, .enable-tabs a').click(function (e) { e.preventDefault(); $(this).tab('show'); });

        // Initialize Tooltips
        $('[data-toggle="tooltip"], .enable-tooltip').tooltip({ container: 'body', animation: false });

        // Initialize Popovers
        $('[data-toggle="popover"], .enable-popover').popover({ container: 'body', animation: true });

        // Initialize Bootstrap Colorpicker
        $('.input-colorpicker').colorpicker({format: 'hex'});
        $('.input-colorpicker-rgba').colorpicker({format: 'rgba'});

        // Datatable
        App.datatables();
        $('#datatable').dataTable({
            "paging": false,
            "searching": false,
            "info": false,
            columnDefs: [
                { orderable: false, targets: 'nosort' }
            ]
        });

        $("#datatable tr th:nth-child(1)").removeClass('sorting_asc ');
        $("#datatable tr th:nth-child(1)").addClass('sorting_disabled ');

        $('.confirm').on('click', function (e) {
            e.preventDefault();
            var aspnetdopostevent = $(this).attr('href');
            $('#modalconfirm').on('click', function (e) {
                window.location = aspnetdopostevent;
            });

            $('#myModal').modal('toggle');
        });

        $("#btn-delete").click(function (e) {

            e.preventDefault();
            var aspnetdopostevent = $(this).attr('href');
            $('#modalconfirm').on('click', function (e) {

                var selectedIDs = new Array();
                $('input:checkbox.cboxselect').each(function () {
                    if ($(this).prop('checked')) {
                        selectedIDs.push($(this).val());
                    }
                });

                var xty = "<form id='frmDelete' method='post' action='" + aspnetdopostevent + "'>";
                xty = xty + "<input name='pidsval' type='hidden' value='" + selectedIDs + "' />";
                xty = xty + "</form>";
                $("body").append(xty);
                $("#frmDelete").submit();
            });

            $('#myModal').modal('toggle');
        });

        $('.confirm-href').on('click', function (e) {

            e.preventDefault();
            var aspnetdopostevent = $(this).attr('href');
            $('#modalconfirm').on('click', function (e) { window.location = aspnetdopostevent; });

            var content = $(this).attr('data-content');
            if (content && content != "" && content != null) {
                $('.modal-body').html(content);
            }

            $('#myModal').modal('toggle');
            return;
        });

        $('#selectall').click(function () {
            var secim = $(this).is(':checked');
            $('.cboxselect').prop('checked', secim);
        });

        $('#selectall2').click(function () {
            var secim = $(this).is(':checked');
            $('.cboxselect2').prop('checked', secim);
        });

        $(".sidebar-nav a").each(function () {
            var href = $(this).attr('href').split("/");
            if (controllerName() === href[2] || controllerName() === $(this).attr("data-other-href")) {
                $(this).closest('li a').addClass('active');
                $(this).parents('li').addClass('active');
            }
        });

        $('#btn-search').click(function (e) {
            e.preventDefault();
            var cst = parseInt($('#search-panel').data('currentstate'));
            if (cst == 0) {
                cst = 1;
                $('#search-panel').slideDown();
                $('html,body').animate({
                    scrollTop: $('#search-panel').offset().top
                }, 1000);
            } else {
                cst = 0;
                $('#search-panel').slideUp();
            }
            $('#search-panel').data('currentstate', cst);
        });

        var cst = parseInt($('#search-panel').data('currentstate'));
        if (cst == 1) {
            $('html,body').animate({
                scrollTop: $('.content-area').offset().top
            }, 1000);
        }


        $('.btn.validate').on('click', function () {
            var forms = $(this).parents("form");
            var forms_name = forms;
            if (forms.attr("id")) {
                forms_name = "#" + forms.attr("id");
            }

            var validater = $(forms_name).validationEngine('validate');

            jqTabValidate();

            return validater;
        });

        $(document).on("click", '.nav-tabs li a', function (e) {
            var href = $(this).attr('href');
            var line = $(href).find('.formError');
            line.hide();
            line.validationEngine('updatePromptsPosition');
            line.show();
            jqTabValidate();
        });

        $('#btn-sort').on('click', function () {
            if ($(".tbl-sorting").length > 0) {
                $.ajax({ url: "/scpanel/" + controllerName() + "/sorting" + window.location.search, success: function (data) { if (data.indexOf("AjaxSorting('") != -1) { $("head").append(data); swalAlert("", sortingText, "success"); } } });
            }
        });

        $('a.PopupOpen').on('click', function (e) {
            e.preventDefault();
            PopupOpen("iframe", $(this).attr('href'));
        });

        $(".fancybox").fancybox({
            openEffect: 'none',
            closeEffect: 'none'
        });

        $(".datepicker").datepicker();

        $('.app-restart').on('click', function () {
            ajaxRequest("GET", "JSON", "/scpanel/home/apprestart", {}, true,
                function (response) {
                    var t = "success";
                    if (response.isError) {
                        t = "error";
                    }
                    swalAlert2("", response.msj, t, pageUrl);
                }
            );
        });

        $('.btn-activepassive').on('click', function () {
            var id = parseInt($(this).closest("tr").attr("data-reorder-id"));
            var tcol = $(this).attr("data-tcol");
            var status = $(this).attr("class").replace("btn-activepassive ", "");
            if (status == "text-success") status = 0;
            else status = 1;

            if (tcol && parseInt(status) > -1 && parseInt(status) < 2 && id > 0) {
                ajaxRequest("POST", "JSON", '/scpanel/' + controllerName() + '/activepassive/' + window.location.search, { "id": id, "status": status, "tcol": tcol }, true,
                    function (response) {
                        var t = "success";
                        if (response.isError) {
                            t = "error";
                        }
                        swalAlert2("", response.msj, t, pageUrl);
                    },
                    null,
                    function (xhr) {
                        if (xhr.msj) {
                            swalAlert("", xhr.msj, "error");
                        }
                        else {
                            window.location.href = "/scpanel/Error/forbidden";
                            return;
                        }
                    }
                );
            }
        });

        $('#btn-reminder-password').on('click', function () {

            var email = $("#txt-reminder-password");
            email.removeAttr('style');

            if (checkEmail(email.val())) {
                ajaxRequest("POST", "JSON", "/Other/AdminReminderPassword", { email: email.val() }, true,
                    function (response) {
                        var t = "success";
                        if (response.isError) {
                            t = "error";
                        }
                        swalAlert2("", response.msj, t, pageUrl);
                    }
                );
            }
            else {
                email.css('border', '1px solid #fc6f6f');
            }
        });
    };

    /* Page Loading functionality */
    var pageLoading = function () {
        var pageWrapper = $('#page-wrapper');

        if (pageWrapper.hasClass('page-loading')) {
            pageWrapper.removeClass('page-loading');
        }
    };

    /* Gets window width cross browser */
    var getWindowWidth = function () {
        return window.innerWidth
            || document.documentElement.clientWidth
            || document.body.clientWidth;
    };

    /* Sidebar Navigation functionality */
    var handleNav = function () {

        // Animation Speed, change the values for different results
        var upSpeed = 250;
        var downSpeed = 250;

        // Get all vital links
        var menuLinks = $('.sidebar-nav-menu');
        var submenuLinks = $('.sidebar-nav-submenu');

        // Primary Accordion functionality
        menuLinks.click(function () {
            var link = $(this);

            if (page.hasClass('sidebar-mini') && page.hasClass('sidebar-visible-lg-mini') && (getWindowWidth() > 991)) {
                if (link.hasClass('open')) {
                    link.removeClass('open');
                }
                else {
                    $('.sidebar-nav-menu.open').removeClass('open');
                    link.addClass('open');
                }
            }
            else if (!link.parent().hasClass('active')) {
                if (link.hasClass('open')) {
                    link.removeClass('open').next().slideUp(upSpeed, function () {
                        handlePageScroll(link, 200, 300);
                    });

                    // Resize #page-content to fill empty space if exists
                    setTimeout(resizePageContent, upSpeed);
                }
                else {
                    $('.sidebar-nav-menu.open').removeClass('open').next().slideUp(upSpeed);
                    link.addClass('open').next().slideDown(downSpeed, function () {
                        handlePageScroll(link, 150, 600);
                    });

                    // Resize #page-content to fill empty space if exists
                    setTimeout(resizePageContent, ((upSpeed > downSpeed) ? upSpeed : downSpeed));
                }
            }

            return false;
        });

        // Submenu Accordion functionality
        submenuLinks.click(function () {
            var link = $(this);

            if (link.parent().hasClass('active') !== true) {
                if (link.hasClass('open')) {
                    link.removeClass('open').next().slideUp(upSpeed, function () {
                        handlePageScroll(link, 200, 300);
                    });

                    // Resize #page-content to fill empty space if exists
                    setTimeout(resizePageContent, upSpeed);
                }
                else {
                    link.closest('ul').find('.sidebar-nav-submenu.open').removeClass('open').next().slideUp(upSpeed);
                    link.addClass('open').next().slideDown(downSpeed, function () {
                        handlePageScroll(link, 150, 600);
                    });

                    // Resize #page-content to fill empty space if exists
                    setTimeout(resizePageContent, ((upSpeed > downSpeed) ? upSpeed : downSpeed));
                }
            }

            return false;
        });
    };

    /* Scrolls the page (static layout) or the sidebar scroll element (fixed header/sidebars layout) to a specific position - Used when a submenu opens */
    var handlePageScroll = function (sElem, sHeightDiff, sSpeed) {
        if (!page.hasClass('disable-menu-autoscroll')) {
            var elemScrollToHeight;

            // If we have a static layout scroll the page
            if (!header.hasClass('navbar-fixed-top') && !header.hasClass('navbar-fixed-bottom')) {
                var elemOffsetTop = sElem.offset().top;

                elemScrollToHeight = (((elemOffsetTop - sHeightDiff) > 0) ? (elemOffsetTop - sHeightDiff) : 0);

                $('html, body').animate({ scrollTop: elemScrollToHeight }, sSpeed);
            } else { // If we have a fixed header/sidebars layout scroll the sidebar scroll element
                var sContainer = sElem.parents('#sidebar-scroll');
                var elemOffsetCon = sElem.offset().top + Math.abs($('div:first', sContainer).offset().top);

                elemScrollToHeight = (((elemOffsetCon - sHeightDiff) > 0) ? (elemOffsetCon - sHeightDiff) : 0);
                sContainer.animate({ scrollTop: elemScrollToHeight }, sSpeed);
            }
        }
    };

    /* Sidebar Functionality */
    var handleSidebar = function (mode, extra) {
        if (mode === 'init') {
            // Init sidebars scrolling functionality
            handleSidebar('sidebar-scroll');
            handleSidebar('sidebar-alt-scroll');

            // Close the other sidebar if we hover over a partial one
            // In smaller screens (the same applies to resized browsers) two visible sidebars
            // could mess up our main content (not enough space), so we hide the other one :-)
            $('.sidebar-partial #sidebar')
                .mouseenter(function () { handleSidebar('close-sidebar-alt'); });
            $('.sidebar-alt-partial #sidebar-alt')
                .mouseenter(function () { handleSidebar('close-sidebar'); });
        } else {
            var windowW = getWindowWidth();

            if (mode === 'toggle-sidebar') {
                if (windowW > 991) { // Toggle main sidebar in large screens (> 991px)
                    page.toggleClass('sidebar-visible-lg');

                    if (page.hasClass('sidebar-mini')) {
                        page.toggleClass('sidebar-visible-lg-mini');
                    }

                    if (page.hasClass('sidebar-visible-lg')) {
                        handleSidebar('close-sidebar-alt');
                    }

                    // If 'toggle-other' is set, open the alternative sidebar when we close this one
                    if (extra === 'toggle-other') {
                        if (!page.hasClass('sidebar-visible-lg')) {
                            handleSidebar('open-sidebar-alt');
                        }
                    }
                } else { // Toggle main sidebar in small screens (< 992px)
                    page.toggleClass('sidebar-visible-xs');

                    if (page.hasClass('sidebar-visible-xs')) {
                        handleSidebar('close-sidebar-alt');
                    }
                }

                // Handle main sidebar scrolling functionality
                handleSidebar('sidebar-scroll');
            }
            else if (mode === 'toggle-sidebar-alt') {
                if (windowW > 991) { // Toggle alternative sidebar in large screens (> 991px)
                    page.toggleClass('sidebar-alt-visible-lg');

                    if (page.hasClass('sidebar-alt-visible-lg')) {
                        handleSidebar('close-sidebar');
                    }

                    // If 'toggle-other' is set open the main sidebar when we close the alternative
                    if (extra === 'toggle-other') {
                        if (!page.hasClass('sidebar-alt-visible-lg')) {
                            handleSidebar('open-sidebar');
                        }
                    }
                } else { // Toggle alternative sidebar in small screens (< 992px)
                    page.toggleClass('sidebar-alt-visible-xs');

                    if (page.hasClass('sidebar-alt-visible-xs')) {
                        handleSidebar('close-sidebar');
                    }
                }
            }
            else if (mode === 'open-sidebar') {
                if (windowW > 991) { // Open main sidebar in large screens (> 991px)
                    if (page.hasClass('sidebar-mini')) { page.removeClass('sidebar-visible-lg-mini'); }
                    page.addClass('sidebar-visible-lg');
                } else { // Open main sidebar in small screens (< 992px)
                    page.addClass('sidebar-visible-xs');
                }

                // Close the other sidebar
                handleSidebar('close-sidebar-alt');
            }
            else if (mode === 'open-sidebar-alt') {
                if (windowW > 991) { // Open alternative sidebar in large screens (> 991px)
                    page.addClass('sidebar-alt-visible-lg');
                } else { // Open alternative sidebar in small screens (< 992px)
                    page.addClass('sidebar-alt-visible-xs');
                }

                // Close the other sidebar
                handleSidebar('close-sidebar');
            }
            else if (mode === 'close-sidebar') {
                if (windowW > 991) { // Close main sidebar in large screens (> 991px)
                    page.removeClass('sidebar-visible-lg');
                    if (page.hasClass('sidebar-mini')) { page.addClass('sidebar-visible-lg-mini'); }
                } else { // Close main sidebar in small screens (< 992px)
                    page.removeClass('sidebar-visible-xs');
                }
            }
            else if (mode === 'close-sidebar-alt') {
                if (windowW > 991) { // Close alternative sidebar in large screens (> 991px)
                    page.removeClass('sidebar-alt-visible-lg');
                } else { // Close alternative sidebar in small screens (< 992px)
                    page.removeClass('sidebar-alt-visible-xs');
                }
            }
            else if (mode == 'sidebar-scroll') { // Handle main sidebar scrolling
                if (page.hasClass('sidebar-mini') && page.hasClass('sidebar-visible-lg-mini') && (windowW > 991)) { // Destroy main sidebar scrolling when in mini sidebar mode
                    if (sScroll.length && sScroll.parent('.slimScrollDiv').length) {
                        sScroll
                            .slimScroll({ destroy: true });
                        sScroll
                            .attr('style', '');
                    }
                }
                else if ((page.hasClass('header-fixed-top') || page.hasClass('header-fixed-bottom'))) {
                    var sHeight = $(window).height();

                    if (sScroll.length && (!sScroll.parent('.slimScrollDiv').length)) { // If scrolling does not exist init it..
                        sScroll
                            .slimScroll({
                                height: sHeight,
                                color: '#fff',
                                size: '3px',
                                touchScrollStep: 100
                            });

                        // Handle main sidebar's scrolling functionality on resize or orientation change
                        var sScrollTimeout;

                        $(window).on('resize orientationchange', function () {
                            clearTimeout(sScrollTimeout);

                            sScrollTimeout = setTimeout(function () {
                                handleSidebar('sidebar-scroll');
                            }, 150);
                        });
                    }
                    else { // ..else resize scrolling height
                        sScroll
                            .add(sScroll.parent())
                            .css('height', sHeight);
                    }
                }
            }
            else if (mode == 'sidebar-alt-scroll') { // Init alternative sidebar scrolling
                if ((page.hasClass('header-fixed-top') || page.hasClass('header-fixed-bottom'))) {
                    var sHeightAlt = $(window).height();

                    if (sScrollAlt.length && (!sScrollAlt.parent('.slimScrollDiv').length)) { // If scrolling does not exist init it..
                        sScrollAlt
                            .slimScroll({
                                height: sHeightAlt,
                                color: '#fff',
                                size: '3px',
                                touchScrollStep: 100
                            });

                        // Resize alternative sidebar scrolling height on window resize or orientation change
                        var sScrollAltTimeout;

                        $(window).on('resize orientationchange', function () {
                            clearTimeout(sScrollAltTimeout);

                            sScrollAltTimeout = setTimeout(function () {
                                handleSidebar('sidebar-alt-scroll');
                            }, 150);
                        });
                    }
                    else { // ..else resize scrolling height
                        sScrollAlt
                            .add(sScrollAlt.parent())
                            .css('height', sHeightAlt);
                    }
                }
            }
        }

        return false;
    };

    /* Resize #page-content to fill empty space if exists */
    var resizePageContent = function () {
        var windowH = $(window).height();
        var sidebarH = sidebar.outerHeight();
        var sidebarAltH = sidebarAlt.outerHeight();
        var headerH = header.outerHeight();
        var footerH = footer.outerHeight();

        // If we have a fixed sidebar/header layout or each sidebars’ height < window height
        if (header.hasClass('navbar-fixed-top') || header.hasClass('navbar-fixed-bottom') || ((sidebarH < windowH) && (sidebarAltH < windowH))) {
            if (page.hasClass('footer-fixed')) { // if footer is fixed don't remove its height
                pageContent.css('min-height', windowH - headerH + 'px');
            } else { // else if footer is static, remove its height
                pageContent.css('min-height', windowH - (headerH + footerH) + 'px');
            }
        } else { // In any other case set #page-content height the same as biggest sidebar's height
            if (page.hasClass('footer-fixed')) { // if footer is fixed don't remove its height
                pageContent.css('min-height', ((sidebarH > sidebarAltH) ? sidebarH : sidebarAltH) - headerH + 'px');
            } else { // else if footer is static, remove its height
                pageContent.css('min-height', ((sidebarH > sidebarAltH) ? sidebarH : sidebarAltH) - (headerH + footerH) + 'px');
            }
        }
    };

    /* Interactive blocks functionality */
    var interactiveBlocks = function () {

        // Toggle block's content
        $('[data-toggle="block-toggle-content"]').on('click', function () {
            var blockContent = $(this).closest('.block').find('.block-content');

            if ($(this).hasClass('active')) {
                blockContent.slideDown();
            } else {
                blockContent.slideUp();
            }

            $(this).toggleClass('active');
        });

        // Toggle block fullscreen
        $('[data-toggle="block-toggle-fullscreen"]').on('click', function () {
            var block = $(this).closest('.block');

            if ($(this).hasClass('active')) {
                block.removeClass('block-fullscreen');
            } else {
                block.addClass('block-fullscreen');
            }

            $(this).toggleClass('active');
        });

        // Hide block
        $('[data-toggle="block-hide"]').on('click', function () {
            $(this).closest('.block').fadeOut();
        });
    };

    /* Scroll to top functionality */
    var scrollToTop = function () {
        // Get link
        var link = $('#to-top');

        $(window).scroll(function () {
            // If the user scrolled a bit (150 pixels) show the link in large resolutions
            if (($(this).scrollTop() > 150) && (getWindowWidth() > 991)) {
                link.fadeIn(100);
            } else {
                link.fadeOut(100);
            }
        });

        // On click get to top
        link.click(function () {
            $('html, body').animate({ scrollTop: 0 }, 400);
            return false;
        });
    };

    /* Template Options, change features functionality */
    var templateOptions = function () {
        /*
         * Color Themes
         */
        var colorList = $('.sidebar-themes');
        var themeLink = $('#theme-link');

        var themeColor = themeLink.length ? themeLink.attr('href') : 'default';
        var cookies = page.hasClass('enable-cookies') ? true : false;

        var themeColorCke;

        // If cookies have been enabled
        if (cookies) {
            themeColorCke = $.cookie('optionThemeColor') ? $.cookie('optionThemeColor') : false;

            // Update color theme
            if (themeColorCke) {
                if (themeColorCke === 'default') {
                    if (themeLink.length) {
                        themeLink.remove();
                        themeLink = $('#theme-link');
                    }
                } else {
                    if (themeLink.length) {
                        themeLink.attr('href', themeColorCke);
                    } else {
                        $('link[href="/themes/admin/css/themes.css"]')
                            .before('<link id="theme-link" rel="stylesheet" href="' + themeColorCke + '">');

                        themeLink = $('#theme-link');
                    }
                }
            }

            themeColor = themeColorCke ? themeColorCke : themeColor;
        }

        // Set the active color theme link as active
        $('a[data-theme="' + themeColor + '"]', colorList)
            .parent('li')
            .addClass('active');

        // When a color theme link is clicked
        $('a', colorList).click(function (e) {
            // Get theme name
            themeColor = $(this).data('theme');

            $('li', colorList).removeClass('active');
            $(this).parent('li').addClass('active');

            if (themeColor === 'default') {
                if (themeLink.length) {
                    themeLink.remove();
                    themeLink = $('#theme-link');
                }
            } else {
                if (themeLink.length) {
                    themeLink.attr('href', themeColor);
                } else {
                    $('link[href="/themes/admin/css/themes.css"]').before('<link id="theme-link" rel="stylesheet" href="' + themeColor + '">');
                    themeLink = $('#theme-link');
                }
            }

            // If cookies have been enabled, save the new options
            if (cookies) {
                $.cookie('optionThemeColor', themeColor, { expires: 7 });
            }
        });

        // Prevent template options dropdown from closing on clicking options
        $('.dropdown-options a').click(function (e) { e.stopPropagation(); });

        /* Page Style */
        var optMainStyle = $('#options-main-style');
        var optMainStyleAlt = $('#options-main-style-alt');

        if (page.hasClass('style-alt')) {
            optMainStyleAlt.addClass('active');
        } else {
            optMainStyle.addClass('active');
        }

        optMainStyle.click(function () {
            page.removeClass('style-alt');
            $(this).addClass('active');
            optMainStyleAlt.removeClass('active');
        });

        optMainStyleAlt.click(function () {
            page.addClass('style-alt');
            $(this).addClass('active');
            optMainStyle.removeClass('active');
        });

        /* Header options */
        var optHeaderDefault = $('#options-header-default');
        var optHeaderInverse = $('#options-header-inverse');

        if (header.hasClass('navbar-default')) {
            optHeaderDefault.addClass('active');
        } else {
            optHeaderInverse.addClass('active');
        }

        optHeaderDefault.click(function () {
            header.removeClass('navbar-inverse').addClass('navbar-default');
            $(this).addClass('active');
            optHeaderInverse.removeClass('active');
        });

        optHeaderInverse.click(function () {
            header.removeClass('navbar-default').addClass('navbar-inverse');
            $(this).addClass('active');
            optHeaderDefault.removeClass('active');
        });
    };

    /* Datatables basic Bootstrap integration (pagination integration included under the Datatables plugin in plugins.js) */
    var dtIntegration = function () { };

    /* Print functionality - Hides all sidebars, prints the page and then restores them (To fix an issue with CSS print styles in webkit browsers)  */
    var handlePrint = function () {
        // Store all #page-container classes
        var pageCls = page.prop('class');

        // Remove all classes from #page-container
        page.prop('class', '');

        // Print the page
        window.print();

        // Restore all #page-container classes
        page.prop('class', pageCls);
    };
    return {
        init: function () {
            uiInit(); // Initialize UI Code
            loadingClose(); // Initialize Page Loading
        },
        sidebar: function (mode, extra) {
            handleSidebar(mode, extra); // Handle sidebars - access functionality from everywhere
        },
        datatables: function () {
            dtIntegration(); // Datatables Bootstrap integration
        },
        pagePrint: function () {
            handlePrint(); // Print functionality
        }
    };
}();

/* Initialize app when page loads */
$(function () { App.init(); });

var loadingOpen = function () {
    $("#status").fadeIn();
    $("#preloader").delay(350).fadeIn("slow");
};

var loadingClose = function () {
    $("#status").fadeOut();
    $("#preloader").delay(350).fadeOut("slow");
};

var tabDegis = function (tix) {
    $('ul[role="tablist"] li').removeClass("active").eq(tix).addClass("active");
    $('div[role="tabpanel"]').removeClass("active").eq(tix).addClass("active");
};

var AjaxSorting = function (c) {
    var TableID = ".tbl-sorting";
    $(TableID).tableDnD({
        onDrop: function () {
            var reorderid = $(TableID + '>tbody>tr').map(function () { return $(this).attr('data-reorder-id'); }).get().join(",");
            ajaxRequest("POST", "JSON", '/scpanel/' + controllerName() + '/sorting/' + window.location.search, { "tcol": c, "reorderid": reorderid }, true,
                function (response) {
                    var t = "success";
                    if (response.isError) {
                        t = "error";
                    }
                    swalAlert2("", response.msj, t, pageUrl);
                }
            );
        }
    });
}

var jqTabValidate = function () {
    $('.tab-pane').each(function (i) {
        var line = $(this).find('.formError');
        var tabpane = $(this).attr("id");
        var el = $(".nav-tabs li a[href$='" + tabpane + "']");
        var txt = $(el).html().replace('<span>***</span>', '');

        if (line.length > 0) {
            $(el).html(txt + '<span>***</span>');
        }
        else {
            $(el).html(txt);
        }
    });
}

var swalAlert = function (_title, _text, _type) {
    swal({
        title: _title,
        text: _text,
        type: _type,
        html: true,
        confirmButtonText: okText
    });
}

var swalAlert2 = function (_title, _text, _type, _redirectUrl) {
    swal({
        title: _title,
        text: _text,
        type: _type,
        html: true,
        confirmButtonText: okText
    },
        function () {
            window.location.href = _redirectUrl
        });
}

var PopupOpen = function (_type, _href, w, auto_size) {
    if (_type == '' || _type == null) _type = "iframe";
    if (w == '' || w == null) {
        var _w = parseInt(window.innerWidth);
        if (_w < 1300) w = "100%";
        else w = "80%";
    }

    if (typeof auto_size == 'undefined' || auto_size == null) auto_size = true;

    if (isMobile.any()) {
        w = '100%';
    }

    jQuery.fancybox.open({
        href: _href,
        type: _type,
        padding: 0,
        fitToView: false,
        autoSize: auto_size,
        autoDimensions: false,
        width: w,
        openEffect: 'elastic',
        openSpeed: 150,
        closeEffect: 'elastic',
        closeSpeed: 150,
        closeClick: false,
        helpers: { overlay: { closeClick: false } }
    });
}

var getUploadFiles = function (input, multiple, selDiv, hdnSorting, check, checkIndex) {
    if (input) {
        if (typeof (FileReader) !== "undefined") {

            $(selDiv).show();
            $(selDiv + " .uploaded-files").html("");
            var i = 0;

            var maxFile = 12;
            if (input.attr("data-maxFile")) maxFile = parseInt(input.attr("data-maxFile"));
            if (input[0].files.length > maxFile) {
                $(input).val('');
                alert(maxResim.replace("{0}", maxFile));
                return;
            }

            $(input[0].files).each(function () {
                var file = $(this);

                var _tempCb = "";
                var reader = new FileReader();
                reader.onload = function (e) {

                    var img_src = "";
                    if (imgRegex.test(file[0].name.toLowerCase())) {
                        img_src = e.target.result;

                        _tempCb = _tempCb + '<li item="' + file[0].name + '">';
                        _tempCb = _tempCb + '<div class="img-center"><img src="' + img_src + '" alt="" /></div>';
                        _tempCb = _tempCb + '<input name="PhotoName"  maxlength="100" class="form-control" value="' + file[0].name.replace(file[0].name.substr(file[0].name.lastIndexOf('.')), '') + '" />';

                        if (multiple && multiple === true && checkIndex !== -1) {
                            _tempCb = _tempCb + '<div class="main-photo"><label>';
                            _tempCb = _tempCb + '<input type="radio" name="IsDefault" value="' + file[0].name + '"';

                            if (check && check === e.target.result) {
                                _tempCb = _tempCb + 'checked="checked"';
                            }
                            else {
                                if (i === checkIndex) _tempCb = _tempCb + 'checked="checked"';
                            }

                            _tempCb = _tempCb + '/>';
                            _tempCb = _tempCb + mainPic + '</label></div>';
                        }

                        _tempCb = _tempCb + '</li>';
                        $(selDiv + " .uploaded-files").append(_tempCb);
                        i++;

                    }
                }
                reader.readAsDataURL(file[0]);
            });

            $(selDiv + " .uploaded-files").sortable({
                cursor: 'move',
                placeholder: 'highlight',
                start: function (event, ui) {
                    ui.item.toggleClass('highlight');
                },
                stop: function (event, ui) {
                    ui.item.toggleClass('highlight');
                },
                update: function () {
                    cvf_reload_order();
                },
                create: function () {
                }
            });
           // $(selDiv + " .uploaded-files").disableSelection();

            cvf_reload_order();
        }
        else {
            alert("This browser does not support HTML5 FileReader.");
        }
    }

    function cvf_reload_order() {
        setTimeout(function () {
            var order = $(selDiv + " .uploaded-files").sortable('toArray', { attribute: 'item' });
            $(hdnSorting).val(order);
        }, 500);
    }
}

var getUploadFile = function (input, selDiv) {
    if (input) {
        if (typeof (FileReader) !== "undefined") {

            var file = input[0].files;
            if (file) {

                var reader = new FileReader();
                reader.onload = function (e) {

                    var img_src = "";
                    if (imgRegex.test(file[0].name.toLowerCase())) {
                        img_src = e.target.result;
                    }
                    else {
                        img_src = getFileIcon(getFileExtension(file[0].name.toLowerCase()));
                    }

                    if (img_src != "none") {
                        $(selDiv + ' .small-image').attr('src', img_src);
                        $(selDiv + ' .small-image').fadeIn();
                        $(selDiv).fadeIn();
                    }
                    else {
                        $(selDiv + ' .small-image').fadeOut();
                    }

                    $(selDiv + ' .input-filename').html(file[0].name);
                }
                reader.readAsDataURL(file[0]);
            }
        }
        else {
            alert("This browser does not support HTML5 FileReader.");
        }
    }
}

function getFileExtension(name) {
    var found = name.lastIndexOf('.') + 1;
    return (found > 0 ? name.substr(name.lastIndexOf('.')) : "");
}

function getFileIcon(a) {
    var b = "file";
    if (a == ".doc" || a == ".docx") {
        b = "doc";
    }
    else if (a == ".xls" || a == ".xlsx") {
        b = "xls";
    }
    else if (a == ".pdf") {
        b = "pdf";
    }
    else if (a == ".zip" || a == ".rar") {
        b = "rar";
    }
    else return "none";

    return "/themes/admin/img/filetype/" + b + ".png";
}

function p_loading_hide(a) {
    setTimeout(function () {
        $(a).removeClass("p_loading");
    }, 500);
}
